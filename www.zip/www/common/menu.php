<title>Welcome to Jai Viklang Clinic</title>


<?php 
// base directory
$base_dir = __DIR__;
// server protocol
$protocol = empty($_SERVER['HTTPS']) ? 'http' : 'https';
// domain name
$domain = $_SERVER['SERVER_NAME'];
// base url
//$base_url = preg_replace("!^${doc_root}!", '', $base_dir);
// server port
$port = $_SERVER['SERVER_PORT'];
$disp_port = ($protocol == 'http' && $port == 80 || $protocol == 'https' && $port == 443) ? '' : ":$port";
// put em all together to get the complete base URL
$url = "${protocol}://${domain}${disp_port}";
session_start();
if ($_SESSION['user'] == null || $_SESSION['type'] == null) {
    header("Location:../index.php");
}
function url_origin($s, $use_forwarded_host = false)
{
    $ssl      = (!empty($s['HTTPS']) && $s['HTTPS'] == 'on');
    $sp       = strtolower($s['SERVER_PROTOCOL']);
    $protocol = substr($sp, 0, strpos($sp, '/')) . (($ssl) ? 's' : '');
    $port     = $s['SERVER_PORT'];
    $port     = ((!$ssl && $port == '80') || ($ssl && $port == '443')) ? '' : ':' . $port;
    $host     = ($use_forwarded_host && isset($s['HTTP_X_FORWARDED_HOST'])) ? $s['HTTP_X_FORWARDED_HOST'] : (isset($s['HTTP_HOST']) ? $s['HTTP_HOST'] : null);
    $host     = isset($host) ? $host : $s['SERVER_NAME'] . $port;
    return $protocol . '://' . $host;
}

function full_url($s, $use_forwarded_host = false)
{
    return url_origin($s, $use_forwarded_host) . $s['REQUEST_URI'];
}
$host_url = url_origin($_SERVER, $use_forwarded_host = false);
$absolute_url = full_url($_SERVER);


?>
<head>
    <link href="<?php echo $host_url ?>/css/bootstrap.min.css" rel="stylesheet"  crossorigin="anonymous" />
	 <link href="<?php echo $host_url ?>/css/bootstrap-theme.min.css" rel="stylesheet"   crossorigin="anonymous" />
    <link href="<?php echo $host_url ?>/css/bootstrap.min.css" rel="stylesheet"   crossorigin="anonymous" />
	<link href="<?php echo $host_url ?>/css/styles.css" rel="stylesheet"   crossorigin="anonymous" />

    <script src="<?php echo $host_url ?>/js/jquery-3.4.1.min.js"   crossorigin="anonymous"></script>
    <script src="<?php echo $host_url ?>/js/bootstrap.min.js"   crossorigin="anonymous"></script>
	<script src="<?php echo $host_url ?>/js/popper.min.js"   crossorigin="anonymous"></script>
<script src="<?php echo $host_url ?>/js/datetimepicker.js"   crossorigin="anonymous"></script>
	
    
<!-- Custom styles for this template -->
<link href="/css/jumbotron.css" rel="stylesheet">
</head>
<script>

$(document).ready(function(){
	console.log("Loading Page...");
	
	$('#addTransaction').on('hidden.bs.modal', function () {
 location.reload();
})
	
	$(document).on('click', '.addEmployee-submit', function(){
		console.log($('#add-employee-form').serialize());
        $.ajax({
            url: '<?php echo $url ?>/admin/employee/addemployee.php', //this is the submit URL
            type: 'GET', //or POST
            data: $('#add-employee-form').serialize(),
            success: function(data){
                
				 $('#AddEmployee').modal('hide');
				  alert('successfully submitted');
            }
        });
		   
});
	
	$('#AddEmployee').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  console.log("Start up modal");
  var modal = $(this)
 // modal.find('.modal-title').text('New message to ' + recipient)
  //modal.find('.modal-body input').val(recipient)
})

$('#AddEmployee').on('hide.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  console.log("Closing up modal");
  var modal = $(this)
  //modal.find('.modal-title').text('New message to ' + recipient)
  //modal.find('.modal-body input').val(recipient)
})

	$("#client_name").keyup(function(event){
	console.log('this------->>>> '+$(this).val());
	var client_name = $(this).val();
	$.ajax('client_detail.php', {
    type: 'get',
    data: { client_name: client_name },
    dataType: 'html',
    success : function(html) {
       console.log("result ----->>>> "+html);
    },
    error: function() {
        alert("Error");
    }
	});
});
});





function renderClientDetails(clientName) {
    if (clientName.length == 0) {
        document.getElementByName("client_name").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
				console.log(this.responseText);
				console.log("this------->>>> "+this);
                //document.getElementByName("client_name").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET", "searchClient.php?client_name=" + clientName, true);
        xmlhttp.send();
    }
}
</script>




<body>

    <nav class="navbar navbar-expand-lg navbar-dark fixed-top bg-dark">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
		<?php
$userType = $_SESSION['userType'];
if (strcmp($_SESSION['userType'], 'A') == 0) {
?>
			<li  class="nav-item"><a  class="nav-link" href="/admin/main.php">Home</a>  </li>
			<li class="nav-item dropdown"><a class="nav-link dropdown-toggle" id="clientDropDown" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Client</a>
				<div class="dropdown-menu" aria-labelledby="clientDropDown">
					<a  class="dropdown-item"  href="/admin/firstappointment.php">Client Registration</a>
					<a  class="dropdown-item"  href="/admin/existingclient.php">Existing Client</a>
				</div>
			</li>
			<li class="nav-item dropdown"><a class="nav-link dropdown-toggle" id="viewDropDown" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">View</a>
				<div class="dropdown-menu" aria-labelledby="viewDropDown">
					<a class="dropdown-item" href="/common/client_detail.php">View Client</a>
					<a class="dropdown-item" href="/common/view_appointment.php">View Appointment</a>
					<a  class="dropdown-item" href="/admin/drreference.php">Doctor's Reference</a>
					<a  class="dropdown-item" href="/admin/edit_doctor.php">Doctor's Details</a>
				</div>
			</li>
			<li  class="nav-item"><a  class="nav-link" href="/admin/employee/empid.php">Employee</a></li>
			<li  class="nav-item"><a  class="nav-link" href="/admin/transactionbetweendate.php">Transactions between Dates</a></li>
			<li  class="nav-item"><a  class="nav-link" href="/admin/fullexistingclientdetail.php">Payment</a></li>
			<li  class="nav-item"><a  class="nav-link" href="/common/client_detail.php">Search</a></li>
			<li  class="nav-item"><a  class="nav-link" href="/admin/deleteclient.php">Delete client</a></li>
		<?php
} else if (strcmp($_SESSION['userType'], 'U') == 0) {
?>
		<li  class="nav-item"><a  class="nav-link" href="/user/main.php">Home</a>  </li>
		<li  class="nav-item"><a  class="nav-link" href="/user/client_registration.php">Client Registration</a>  </li>
		<li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" id="viewDropDown" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Appointment</a>
			<div class="dropdown-menu" aria-labelledby="viewDropDown">
                 <a class="dropdown-item" href="/common/view_appointment.php">View Appointment</a>
                 <a class="dropdown-item" href="/user/addappointment.php">Add Appointment</a>
                            </div>
		</li>
        <li><a class="nav-link" href="/common/client_detail.php">View Client</a></li>
        <li><a class="nav-link" href="/user/deleteclient.php">Delete</a></li>
        

			
		<?php
}
?>
<li><a class="nav-link" href="../logout.php">Logout</a></li>
		</ul>
	</div>
</nav>







<div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
<li>             
<?php if (strcmp($_SESSION['userType'], 'A') == 0) {
?>
			  <img src="<?php echo $url?>/images/doc.jpg" class="img-fluid img-thumbnail rounded-circle" alt="Avatar"> 
<?php }else{
	?>
			  <img src="<?php echo $url?>/images/1.png" class="img-fluid img-thumbnail rounded-circle" alt="Avatar"> 
	
	<?php
} ?>
</li>
			  
			  <li class="nav-item">
                <a class="nav-link active" href="#">
                  <span data-feather="home"></span>
                  Welcome Dr. <?php echo $_SESSION['user']; ?><span class="sr-only">(Current)</span>
                </a>
              </li>
			  
               <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="shopping-cart"></span>
                  Products
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="users"></span>
                  Customers
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="bar-chart-2"></span>
                  Reports
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="layers"></span>
                  Integrations
                </a>
              </li>
            </ul>

            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
              <span>Saved reports</span>
              <a class="d-flex align-items-center text-muted" href="#">
                <span data-feather="plus-circle"></span>
              </a>
            </h6>
            <ul class="nav flex-column mb-2">
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Current month
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Last quarter
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Social engagement
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="file-text"></span>
                  Year-end sale
                </a>
              </li>
            </ul>
          </div>
        </nav>
</body>
</html>


    