﻿
<head>
    <script language="javascript" type="text/javascript" src="../js/datetimepicker.js">
    </script>

   </head>

<?php
include '../common/menu.php';
include '../db.php';


$paid = 0;
if (isset($_REQUEST['start_date'])) {
    $start_date = $_REQUEST['start_date'];
    $query = "select p.client_id as client_id,c.client_name as client_name,
	c.age as age,c.problem as problem,
	c.refer as refer,c.dr_refer as dr_refer,p.date as date,
	p.next_appointment as next_appointment,
	c.phone_no as phone_no
	from client c,paid p where p.client_id=c.client_id and p.next_appointment= STR_TO_DATE('" . $start_date . "','%d-%c-%Y') group by client_id";
    $result = mysqli_query($con,$query) or die(mysql_errno() . " : " . mysql_error() . " : Please Contact Your System Administrator");
?>
    
    <table class="table table-striped style="width: 90%">
        <thead>
		<tr><th colspan="4" class="col-md-16">Appointment Details Of Clients on <?php echo $start_date ?>(dd-mm-yyyy)</th></tr>
            <tr>
                <th>Client ID</th>
                <th>Client Name</th>
				<th>Phone Number</th>
                <th nowrap>Age</th>
          <?php
			if (strcmp($_SESSION['userType'], 'A') == 0) {
			  echo "<th nowrap>Problem</th>
                <th nowrap>Prisciptions</th>
                <th nowrap>Doctor's Reference</th>" ;
			}?>
                <th>Date</th>
                <th>Next Appointment</th>
            </tr>
        </thead>
        <tbody>

<?php
    while ($row = mysqli_fetch_array($result)) {
?>
        <tr>
            <td ><?php echo $row['client_id'] ?></td>
            <td nowrap><?php echo $row['client_name'] ?></td>
            <td nowrap><?php echo $row['phone_no'] ?></td>
            <td nowrap><?php echo $row['age'] ?></td>
<?php
			if (strcmp($_SESSION['userType'], 'A') == 0) {     
	  echo "<td >".$row['problem']."</td>
           <td>".$row['refer']."</td>
            <td >".$row['dr_refer']."</td>";
			}?>
            <td nowrap><?php echo $row['date'] ?></td>
            <td nowrap><?php echo $row['next_appointment'] ?></td>

        </tr>


<?php } ?>

    </tbody>
</table>

        <?php

    } else {
        ?><form method="post" action="">
<center>
    <br>
    <strong font-size: large text-align: center ><h2>View Appointments</h2> <br>
    </strong><br>

    <strong font-size: large text-align: center  >Enter Date :</strong> <input id="demo3" name="start_date" type="text" size="25"><a href="javascript:NewCal('demo3','ddMMyyyy')"><img src="../cal.gif" width="16" height="16" border="0" alt="Pick a date"></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <br>
    <br>
    <br>
    <input name="Submit1" type="submit" value="Submit Details" class='btn btn-primary btn-sm'><br>
</center>

</form>

<?php }         include '../footer.php';?>