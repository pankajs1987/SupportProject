 <?php
 
include 'menu.php';
include '../db.php';
       
        if (isset($_GET['pageno'])) {
            $pageno = $_GET['pageno'];
        } else {
            $pageno = 1;
        }

         $no_of_records_per_page = 50;
        $offset = ($pageno-1) * $no_of_records_per_page;
		$query = "SELECT * FROM client	";
		$where_condition=" where status <> 'Dummy' ";
		$whereClause = "";
		$client_name="";
		$client_id="";
		$phone_no="";
		$dr_refer="";
		$status="";
		if (isset($_GET['client_name']) && $_GET['client_name'] <> "") {
			$where_condition .=" and ";
			$whereClause ="C";
			$where_condition .= "client_name like '%".$_GET['client_name']."%'";
			$client_name=$_GET['client_name'];
        }
		if (isset($_GET['client_id']) && $_GET['client_id'] <> "") {
			$where_condition .=" and ";
			$whereClause ="C";
			$where_condition .= "client_id like '%".$_GET['client_id']."%'";
        }
		if (isset($_GET['phone_no'])  && $_GET['phone_no'] <> "") {
			if($whereClause ==="C"){
				$where_condition .= " or";	
			}else{
				$where_condition .= " and";
			}
			$where_condition .= " phone_no like '%".$_GET['phone_no']."%'";
			$phone_no=$_GET['phone_no'];
        }
		if (isset($_GET['dr_refer'])  && $_GET['dr_refer'] <> "") {
			$where_condition .= " and dr_refer like '%".$_GET['dr_refer']."%'";
			$dr_refer=$_GET['dr_refer'];
        }
		if (isset($_GET['status'])  && $_GET['status'] <> "") {
			$where_condition .= " and status = '".$_GET['status']."'";
			$status=$_GET['status'];
        }
		$query .=$where_condition;
		$query .= " order by date desc LIMIT $offset,$no_of_records_per_page;";
		$total_pages_sql = "SELECT COUNT(*) FROM client";
		$total_pages_sql .= $where_condition;
        $result = mysqli_query($con,$total_pages_sql);
        $total_rows = mysqli_fetch_array($result)[0];
        $total_pages = ceil($total_rows / $no_of_records_per_page);
        mysqli_free_result($result);
		$userType = $_SESSION['userType'];
		//echo $query;
        ?>
    <center>


 <form action="<?php echo $absolute_url?>" method="GET">

        
            <table class="table">
			<th class="thead-dark" colspan=4> Search Customer</th>
                <tbody>		
				<tr>
				<td>Client Id </td>
                        <td><input type="text"  name="client_id" value="<?php echo $client_id ?>" size="40"  /></td>
                        <td>Name </td>
                        <td><input type="text"  name="client_name" value="<?php echo $client_name ?>" size="50"  /></td>
				</tr>
                    <tr>
					 
						<td>Phone Number </td>
                        <td><input type="text"  name="phone_no" value="<?php echo $phone_no ?>" size="40"  /></td>
 <?php if($userType==="A")
			{		?>			
					<td>Refered By </td>
                        <td><input type="text"  name="dr_refer" value="<?php echo $dr_refer ?>" size="50"  /></td>
                    </tr>
			<?php }?>   
			
                        <td nowrap colspan=2>
						
						
						
						
						
	 <div class="input-group mb-3">
         <div class="input-group-prepend">
            <label class="input-group-text col-md-20 mb-3" for="status">Client Status</label>
         </div>
         <select class="custom-select col-md-20 mb-3" name="status">
            <option selected value="">Choose...</option>
            <option value="Active">Active</option>
			<option value="Final">Final</option>
         </select>
         <div class="invalid-feedback" >
            Please select a valid User Type.
         </div>
		</td>
                    </tr>
                </tbody>
            </table>

			<div class="col-md-16 text-center">
			<input class="btn btn-primary" type="reset" value="Reset" />
            <input class="btn btn-primary" type="submit" value="Submit Details" /></div>

        


    </form>

	
    <ul class="pagination float-right">
        <li>
		<a class='page-link' href="<?php echo"?client_name=".$client_name."&status=".$status."&phone_no=".$phone_no."&dr_refer=".$dr_refer."&pageno=1"?>">First</a></li>
        <li class="<?php if($pageno <= 1){ echo 'page-item disabled'; } ?>">
            <a class='page-link' href="<?php if($pageno <= 1){ echo '#'; } else { echo "?client_name=".$client_name."&status=".$status."&phone_no=".$phone_no."&dr_refer=".$dr_refer."&pageno=".($pageno - 1); } ?>">Prev</a>
        </li>
        <li class="<?php if($pageno >= $total_pages){ echo 'page-item disabled'; } ?>">
            <a class='page-link' href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?client_name=".$client_name."&status=".$status."&phone_no=".$phone_no."&dr_refer=".$dr_refer."&pageno=".($pageno + 1); } ?>">Next</a>
        </li>
        <li><a class='page-link' href="<?php echo"?client_name=".$client_name."&status=".$status."&phone_no=".$phone_no."&dr_refer=".$dr_refer."&pageno=".$total_pages;?>">Last</a></li>
    </ul>

<table class="table table-striped"  >

    <thead>
        <tr>
            <th  nowrap>Client ID </th>
            <th  nowrap>Client Name</th>
         <?php if($userType==="A")
		 {   
		 echo "<th  nowrap>Doctor's Reference</th>"; 
		 }
		 ?>
		 <th  nowrap>Status</th>
			<th  nowrap>Phone Number</th>
            <th  nowrap>Date of Joining</th>
        </tr>
    </thead>
<tbody id="client_details">
                <?php
                $query_result= mysqli_query($con, $query);
                while($row=mysqli_fetch_assoc($query_result)) {
        ?><tr  <?php if($row['status']==="FINAL"){   echo "class='alert alert-danger'"; } ?> >
            <td  nowrap><?php echo $row['client_id']; ?></td>
            <td  nowrap><?php echo $row['client_name']; ?></td>
           <?php if($userType==="A")
			{   
			echo "<td  nowrap>" .$row['dr_refer']. "</td>"; 
		 }?>
		 <td  nowrap><?php echo $row['status']; ?></td>
			<td  nowrap><?php echo $row['phone_no']; ?></td>
            <td  nowrap><?php echo $row['date']; ?></td>
        </tr>
          <?php
          
                }
            


           ?>


    </tbody>
</table>
 </center>
<?php include '../footer.php'; ?>



