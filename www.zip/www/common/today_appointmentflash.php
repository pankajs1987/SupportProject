<?php
include '../db.php';

$date=date("Y-m-d");
$query="select p.client_id as client_id,c.client_name as client_name,c.problem as problem,c.refer as refer,c.dr_refer as dr_refer,c.phone_no as phone_no,c.age as age,c.amount as amount from paid p,client c where day(p.date)=day(curdate()) and month(p.date)=month(curdate()) and year(p.date)=year(curdate()) and p.client_id=c.client_id group by client_id";
$result=mysqli_query($con,$query) or die("Some Problem has been Occured in Executing Your Query,Please Contact Your System Administrator");


?>
   <marquee direction="up" behavior="alternate" scrolldelay="100" onmouseover="stop();" onmouseout="start();" >
       <table  class="table table-striped" >
            <thead>
                <tr>
                    <th>Client ID</th>
                    <th>Client Name</th>
                    <th>Problem</th>
                    <th>Precistion</th>
                <!-- this should be visible to doctor only -->
<?php  if (strcmp($_SESSION['userType'], 'A') == 0) {
?> 
				<th>Refered By</th>
<?php }?>				<!-- this should be visible to doctor only -->
					
				<!-- Added for Operator-->
<?php  if (strcmp($_SESSION['userType'], 'U') == 0) {
?>      
					<th>Phone Number</th>
                    <th>Age</th>
                 <!--Added for Operator-->   
<?php }?>                    

                </tr>
            </thead>
            <tbody>
             
 <?php
while($row=mysqli_fetch_array($result))
{
    ?>

                <tr>
                    <td><?php echo $row['client_id']; ?></td>
                    <td><?php echo $row['client_name'];?></td>
                    <td><?php echo $row['problem']; ?></td>
                    <td><?php echo $row['refer']; ?></td>
				<?php  if (strcmp($_SESSION['userType'], 'A') == 0) {
 
					echo "<td>".$row['dr_refer']."</td>";
				}
			
				if (strcmp($_SESSION['userType'], 'U') == 0) {
						echo "<td>".$row['phone_no']."</td>";
						echo "<td>".$row['age']."</td>";
					}?>
                    

                </tr>
    <?php }?>

                </tbody>

                </table>
</marquee>

