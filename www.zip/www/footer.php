<?php echo'<center  class="mt-5 mb-3 text-muted">';?>

<footer class="footer">
	  <div class="container ">
  <address>
    <abbr title="Contact">Contact:</abbr>Galaxy Royale,Gaur City 2,Greater Noida West<br />
    Ghaziabad,Uttar Pradesh-244001<br />
    <abbr title="Phone">P:</abbr> (+91) 9592727121
  </address>

  <address>
    <strong>Pankaj Sharma</strong><br />
    <a href="mailto:#">pankajtmimt2008@gmail.com</a>
  </address>
</div>
</footer>
</div>


