 <?php
/**
 *contains properties and methods for "client" database queries.
 */

class Client
{
    
    //Db connection and table
    private $conn;
    private $table_name = 'client';
    public $id;
    public $name;
    public $problem;
    public $refer;
    public $date;
    public $amount;
    public $address;
    public $age;
    public $phone_no;
    public $client_id;
    public $status;
    public $cliId;
    public $dr_refer;
    
    
    //Constructor with db conn
    public function __construct($db)
    {
        $this->conn = $db;
    }
    
    
    //Read product
    function read()
    {
        
        $clientDetails = "SELECT `client`.`client_name`,`client`.`problem`,`client`.`refer`,`client`.`date`,`client`.`amount`,`client`.`address`,
        `client`.`age`,`client`.`phone_no`,`client`.`client_id`,`client`.`dr_refer`,`client`.`status`,`client`.`cli_id`,`client`.`id` FROM " . $this->table_name . " `client`;";
        
        //select all
        $query = "SELECT
                    c.name AS category_name, p.id, p.name, p.description, p.price, p.category_id, p.created
                  FROM
                  " . $this->table_name . " p
                  LEFT JOIN
                    categories c ON p.category_id = c.id
                  ORDER BY
                    p.created DESC";
        
        //prepare
        $stmt = $this->conn->prepare($clientDetails);
        
        //execute
        $stmt->execute();
        
        return $stmt;
        
    }
    
    
    //read single product
    function readOne()
    {
        
        //read single record
        $query = "SELECT
                c.name as category_name, p.id, p.name, p.description, p.price, p.category_id, p.created
            FROM
                " . $this->table_name . " p
                   LEFT JOIN
                    categories c ON p.category_id = c.id
                   WHERE
                   p.id = ? LIMIT 0,1";
        
        //prepare
        $stmt = $this->conn->prepare($query);
        
        //bind id of product
        $stmt->bindParam(1, $this->id);
        
        //execute
        $stmt->execute();
        
        //fetch row
        $row              = $stmt->fetch(PDO::FETCH_ASSOC);
        //set values to update
        $this->$id        = $row['id'];
        $this->$name      = $row['name'];
        $this->$problem   = $row['problem'];
        $this->$refer     = $row['refer'];
        $this->$date      = $row['date'];
        $this->$amount    = $row['amount'];
        $this->$address   = $row['address'];
        $this->$age       = $row['age'];
        $this->$phone_no  = $row['phone_no'];
        $this->$client_id = $row['client_id'];
        $this->$status    = $row['status'];
        $this->$cliId     = $row['cliId'];
        
    }
        
    //delete product
    function delete()
    {
        
        //delete query
        $query = " DELETE FROM " . $this->table_name . " WHERE id = ?";
        
        //prepare
        $stmt = $this->conn->prepare($query);
        
        //sanitize
        $this->id = htmlspecialchars(strip_tags($this->id));
        
        //bind id
        $stmt->bindParam(1, $this->id);
        
        //execute
        if ($stmt->execute()) {
            return true;
        }
        
        return false;
    }
    
    //search products
    function search($keywords)
    {
        
        //select all query
        $query = "SELECT
                    c.name as category_name, p.id, p.name, p.description, p.price, p.category_id, p.created
                  FROM " . $this->table_name . " p
                  LEFT JOIN
                    categories c ON p.category_id = c.id
                  WHERE
                    p.name LIKE ? OR p.description LIKE ? OR c.name LIKE ?
                  ORDER BY
                    p.created DESC";
        
        //prepare
        $stmt = $this->conn->prepare($query);
        
        //sanitize
        $keywords = htmlspecialchars(strip_tags($keywords));
        $keywords = "%{$keywords}%";
        
        //bind
        $stmt->bindParam(1, $keywords);
        $stmt->bindParam(2, $keywords);
        $stmt->bindParam(3, $keywords);
        
        //execute
        $stmt->execute();
        
        return $stmt;
    }
    
    //read products with pagination
    public function readPaging($from_record_num, $records_per_page)
    {
        
        //select
        $query = "SELECT
                    c.name as category_name, p.id, p.name, p.description, p.price, p.category_id, p.created
                  FROM " . $this->table_name . " p
                  LEFT JOIN
                    categories c ON p.category_id = c.id
                  ORDER BY p.created DESC
                  LIMIT ?, ?";
        
        //prepare
        $stmt = $this->conn->prepare($query);
        
        //bind
        $stmt->bindParam(1, $from_record_num, PDO::PARAM_INT);
        $stmt->bindParam(2, $records_per_page, PDO::PARAM_INT);
        
        //execute
        $stmt->execute();
        
        //return values from db
        return $stmt;
    }
    
    
    //paging products
    public function count()
    {
        $query = "SELECT COUNT(*) as total_rows FROM " . $this->table_name . "";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $row['total_rows'];
        
    }
	
	function update()
    {
        $query = "UPDATE
              " . $this->table_name . "
              SET
                client_id=:client_id,
                problem=:problem,
                refer=:refer,
                dr_refer=:dr_refer
				where client_id=:client_id";
        
        $stmt = $this->conn->prepare($query);
        
        //sanitize
        $this->client_id = htmlspecialchars(strip_tags($this->client_id));
        $this->problem   = htmlspecialchars(strip_tags($this->problem));
        $this->refer     = htmlspecialchars(strip_tags($this->refer));
        $this->dr_refer  = htmlspecialchars(strip_tags($this->dr_refer));
        
        //Bind values
        $stmt->bindParam(":client_id", $this->client_id);
        $stmt->bindParam(":problem", $this->problem);
        $stmt->bindParam(":refer", $this->refer);
        $stmt->bindParam(":dr_refer", $this->dr_refer);
        //execute
        if ($stmt->execute()) {
            return true;
        }
        
        return false;
    }

    
    function create()
    {
        $query = "INSERT INTO
              " . $this->table_name . "
              SET
                client_id=:client_id,
                problem=:problem,
                refer=:refer,
                amount=:amount,
                status=:status,
                client_name=:client_name,
                age=:age,
                phone_no=:phone_no,
                address=:address,
                date=STR_TO_DATE(:date),
                dr_refer=:dr_refer";
        
        
        //Prepare
        //echo $query;
        $stmt = $this->conn->prepare($query);
        
        //sanitize
        $this->client_id = htmlspecialchars(strip_tags($this->client_id));
        $this->name      = htmlspecialchars(strip_tags($this->name));
        $this->problem   = htmlspecialchars(strip_tags($this->problem));
        $this->refer     = htmlspecialchars(strip_tags($this->refer));
        $this->amount    = htmlspecialchars(strip_tags($this->amount));
        $this->status    = htmlspecialchars(strip_tags($this->status));
        $this->age       = htmlspecialchars(strip_tags($this->age));
        $this->phone_no  = htmlspecialchars(strip_tags($this->phone_no));
        $this->address   = htmlspecialchars(strip_tags($this->address));
        $this->date      = htmlspecialchars(strip_tags($this->date));
        $this->dr_refer  = htmlspecialchars(strip_tags($this->dr_refer));
        
        //Bind values
        $stmt->bindParam(":client_id", $this->client_id);
        $stmt->bindParam(":problem", $this->problem);
        $stmt->bindParam(":refer", $this->refer);
        $stmt->bindParam(":amount", $this->amount);
        $stmt->bindParam(":status", $this->status);
        $stmt->bindParam(":client_name", $this->name);
        $stmt->bindParam(":age", $this->age);
        $stmt->bindParam(":phone_no", $this->phone_no);
        $stmt->bindParam(":address", $this->address);
        $stmt->bindParam(":date", $this->date);
        $stmt->bindParam(":dr_refer", $this->dr_refer);
        //execute
        if ($stmt->execute()) {
            return true;
        }
        
        return false;
    }
} 