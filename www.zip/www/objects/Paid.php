<?php
/**
*contains properties and methods for "Paid" database queries.
 */

class Paid
{

    //Db connection and table
    private $conn;
    private $table_name = 'paid';
    public $id;
    public $total_payment;
    public $paid;
	public $date;
	public $renew;
	public $next_appointment;
	
    
    //Constructor with db conn
    public function __construct($db)
    {
        $this->conn = $db;
    }


   

    //update product
    function update(){

        //update query
        $query = "UPDATE
                    " . $this->table_name. "
                    SET
                        client_id=:client_id,
                        total_payment=:total_payment,
                        paid=:paid,
                        date=:date,
						next_appointment=:next_appointment
                    WHERE
                        id=:id";

        //prepare
        $stmt = $this->conn->prepare($query);

        //sanitize
        $this->name=htmlspecialchars(strip_tags($this->name));
        $this->price=htmlspecialchars(strip_tags($this->price));
        $this->description=htmlspecialchars(strip_tags($this->description));
        $this->category_id=htmlspecialchars(strip_tags($this->category_id));
        $this->id=htmlspecialchars(strip_tags($this->id));

        //bind new values
        $stmt->bindParam(':name', $this->name);
        $stmt->bindParam(':price', $this->price);
        $stmt->bindParam(':description', $this->description);
        $stmt->bindParam(':category_id', $this->category_id);
        $stmt->bindParam(':id', $this->id);

        //execute
        if($stmt->execute()){
            return true;
        }

        return false;
    }

   
    //search products
    function search($keywords){

        //select all query
        $query = "SELECT
                    c.name as category_name, p.id, p.name, p.description, p.price, p.category_id, p.created
                  FROM " . $this->table_name. " p
                  LEFT JOIN
                    categories c ON p.category_id = c.id
                  WHERE
                    p.name LIKE ? OR p.description LIKE ? OR c.name LIKE ?
                  ORDER BY
                    p.created DESC";

        //prepare
        $stmt =$this->conn->prepare($query);

        //sanitize
        $keywords = htmlspecialchars(strip_tags($keywords));
        $keywords = "%{$keywords}%";

        //bind
        $stmt->bindParam(1, $keywords);
        $stmt->bindParam(2, $keywords);
        $stmt->bindParam(3, $keywords);

        //execute
        $stmt->execute();

        return $stmt;
    }

   
function create(){
    //query insert
	
    $query = "INSERT INTO
              ". $this->table_name ."
                   SET
                        client_id=:client_id,
                        total_payment=:total_payment,
                        paid=:paid,
                        date=curdate(),
						next_appointment=STR_TO_DATE(:next_appointment,'%d-%c-%Y')";


  
    $stmt = $this->conn->prepare($query);
	$stmt->bindParam(":client_id", $this->client_id,PDO::PARAM_STR);
    $stmt->bindParam(":total_payment", $this->total_payment,PDO::PARAM_INT);
    $stmt->bindParam(":paid", $this->paid,PDO::PARAM_INT);
    $stmt->bindParam(":next_appointment", $this->next_appointment);
	try{
		if($stmt->execute()){
	    return true;
    }
		return false;	
	}
catch (Exception $e) {
    	echo $stmt->debugDumpParams();
		$stmt->errorCode();
		$stmt->errorInfo();
		echo $e->getMessage();
}
}
}