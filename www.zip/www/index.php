<?php
if (isset($_REQUEST['user']) && isset($_REQUEST['password']) && isset($_REQUEST['user_type'])) {
$error="";
$user = $_REQUEST['user'];
$pass = $_REQUEST['password'];
$type = $_REQUEST['user_type'];
 session_start();
  $_SESSION['user'] = $user;
  $_SESSION['type'] = $type;
  if($type==="Operator"){
			$_SESSION['userType']="U";
	}
	if($type==="Administrator"){
			$_SESSION['userType']="A";
	}

include("db.php");
$query = "select * from login where user='" . $user . "' and password='" . $pass . "' and user_type='" . $type . "'";
$result = mysqli_query($con,$query) or die("Can not execute Query");
$affected_row = mysqli_num_rows($result);
echo $affected_row;
if ($affected_row == 1  && $type == "Operator") {
  //echo 'I m in Operator';
    header("Location:user/main.php");
} else if ($affected_row == 1 && $type == "Administrator") {
   // echo 'I m in Admin';
    header("Location:admin/main.php");
} else {
    header("Location:/");
}
} 

?>
<!doctype html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <link rel="icon" href="favicon.ico">
      <title>Welcome to Jai Viklang Clinic</title>
      <!-- Bootstrap core CSS -->
      <link href="<?php echo gethostname() ?>/css/bootstrap.min.css" rel="stylesheet">
      <!-- Custom styles for this template -->
      <link href="<?php echo gethostname() ?>/css/signin.css" rel="stylesheet">
	  
	  <link href="<?php echo gethostname() ?>/css/bootstrap.min.css" rel="stylesheet">
	<link href="<?php echo gethostname() ?>/css/styles.css" rel="stylesheet">
	 <link href="<?php echo gethostname() ?>/css/bootstrap-theme.min.css" rel="stylesheet">
    <script src="<?php echo gethostname() ?>/js/jquery-3.3.1.slim.min.js"></script>
    <script src="<?php echo gethostname() ?>/js/popper.min.js"></script>
    <script src="<?php echo gethostname() ?>/js/bootstrap.min.js"></script>
	<script src="<?php echo gethostname() ?>/js/jquery-3.3.1.slim.min.js"></script>
    <script src="<?php echo gethostname() ?>/js/popper.min.js"></script>
    <script src="<?php echo gethostname() ?>/js/bootstrap.min.js"></script>
	  
   </head>
   <body class="text-center">
      <form class="form-signin needs-validation" novalidate method="post" action="index.php">
         <h1 class="h3 mb-3 col-md-10 mb-10 font-weight-normal">Please sign in</h1>
         <div class="col-md-20 mb-3">
            <label for="inputEmail" class="sr-only">Email address</label>
            <input type="text" name="user" id="inputEmail" class="form-control" placeholder="Email address" required autofocus>
         </div>
         <div class="col-md-20 mb-3">
            <label for="inputPassword" class="sr-only">Password</label>
            <input type="password" name="password" id="inputPassword" class="form-control col-md-20" placeholder="Password" required>
         </div>
         <div class="input-group mb-3">
         <div class="input-group-prepend">
            <label class="input-group-text col-md-20 mb-3" for="user_type">User Type</label>
         </div>
         <select class="custom-select col-md-20 mb-3" name="user_type">
            <option selected="">Choose...</option>
            <option value="Administrator">Administrator</option>
            <option value="Operator">Operator</option>
         </select>
         <div class="invalid-feedback" >
            Please select a valid User Type.
         </div>
         <button class="btn btn-lg col-md-20 mb-3 btn-primary btn-block" type="submit">Sign in</button>
      </form>
      <?php include 'footer.php'; ?>
   </body>
</html>





