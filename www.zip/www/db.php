<?php
$con=mysqli_connect("localhost:3306","root","root","doctor")or die("could not connect to database");
mysqli_select_db($con,"doctor")or
	die("Could Not Select Database");
?>


<div class="container">

