<?php

//Req headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset:UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

//Req includes
include_once '../config/database.php';
include_once '../objects/Client.php';

//Db conn and instances
$database = new Database();
$db=$database->getConnection();

$client = new Client($db);


//Get post data
$data = json_decode(file_get_contents("php://input"));

//set product values


$client->name = $data->name;
$client->problem = $data->problem;
$client->refer = $data->refer;
$client->date = $data->date;
$client->amount = $data->amount;
$client->address = $data->address;
$client->age = $data->age;
$client->phone_no = $data->phone_no;
$client->client_id = $data->client_id;
$client->status = $data->status;

echo 'reaching here';
//Create Client
if($client->create()){
    echo '{';
        echo '"message": "Product was created."';
    echo '}';
}else{
    echo '{';
        echo '"message": "Unable to create product."';
    echo '}';
}

function create(){
echo 'reaching here';
    //query insert
	$table_name = 'client';
    $query = "INSERT INTO
              client
              SET
                client_id=:client_id,
				problem=:problem,
				refer=:refer,
				amount=:amount,
				status=:status,
				client_name=:client_name,
				age=:age,
				phone_no=:phone_no,
				address=:address,
				date=:date,
				dr_refer=:dr_refer;";


    //Prepare
    $stmt = $this->conn->prepare($query);

    //sanitize
    $this->client_id=htmlspecialchars(strip_tags($this->client_id));
    $this->name=htmlspecialchars(strip_tags($this->name));
    $this->problem=htmlspecialchars(strip_tags($this->problem));
    $this->refer=htmlspecialchars(strip_tags($this->refer));
    $this->amount=htmlspecialchars(strip_tags($this->amount));
    $this->status=htmlspecialchars(strip_tags($this->status));
    $this->age=htmlspecialchars(strip_tags($this->age));
    $this->phone_no=htmlspecialchars(strip_tags($this->phone_no));
    $this->address=htmlspecialchars(strip_tags($this->address));
    $this->date=htmlspecialchars(strip_tags($this->date));
    $this->dr_refer=htmlspecialchars(strip_tags($this->dr_refer));
    
    //Bind values
    $stmt->bindParam(":client_id", $this->client_id);
    $stmt->bindParam(":problem", $this->problem);
    $stmt->bindParam(":refer", $this->refer);
    $stmt->bindParam(":amount", $this->amount);
    $stmt->bindParam(":status", $this->status);
    $stmt->bindParam(":client_name", $this->name);
    $stmt->bindParam(":age", $this->age);
    $stmt->bindParam(":phone_no", $this->phone_no);
    $stmt->bindParam(":address", $this->address);
    $stmt->bindParam(":date", $this->date);
    $stmt->bindParam(":dr_refer", $this->dr_refer);
    //execute
    if($stmt->execute()){
        return true;
    }
    return false;
}
