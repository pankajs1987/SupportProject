<?php
include 'menu.php';
include '../db.php';
$total_amount=0;
$total_paid=0;
$query="SELECT p.client_id as client_id,sum(p.total_payment) as total,sum(p.paid) as paid FROM paid p group by p.client_id;";
$result=  mysql_query($query,$con);

?>
<center><table border="2">
<thead>
<tr>
<th>Client ID</th>
<th>Total Amount </th>
<th>Total Paid</th>
<th>Due</th>

</tr>
</thead>
<tbody>
<?php while($row=  mysql_fetch_array($result)) {?>
<tr>
<?php
$total_amount+=$row['total'];
$total_paid+=$row['paid'];
?>
    <td><?php echo $row['client_id']; ?></td>
<td><?php echo $row['total']; ?></td>
<td><?php echo $row['paid']; ?></td>
<td><?php echo $row['total']-$row['paid']; ?></td>

</tr>
<?php }
?>

</tbody>
</table>
</center>
<?php include '../footer.php'; ?>
