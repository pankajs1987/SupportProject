<?php
$base_dir = __DIR__;
$protocol = empty($_SERVER['HTTPS']) ? 'http' : 'https';
$domain = $_SERVER['SERVER_NAME'];
$port = $_SERVER['SERVER_PORT'];
$disp_port = ($protocol == 'http' && $port == 80 || $protocol == 'https' && $port == 443) ? '' : ":$port";
// put em all together to get the complete base URL
$url = "${protocol}://${domain}${disp_port}";
include '../common/menu.php';
include '../db.php';

if (isset($_REQUEST['client_id'])) {
    $client_id = $_REQUEST['client_id'];
    $query = "SELECT c.status,p.client_id,c.client_name as client_name,c.phone_no as phone_no,c.date as date,c.problem as problem,c.refer as refer,c.dr_refer as dr_refer,c.address,c.age as age,sum(p.total_payment) as total,sum(p.paid) as paid,count(p.client_id) as meeting FROM paid p,client c where p.client_id=c.client_id  and p.client_id='" . $client_id . "'";
   
	$result = mysqli_query($con,$query) or die(mysql_errno() . ":" . mysql_error() . ": Please Contact Your System Administrator");
	
	$query = "SELECT * from paid where client_id ='" . $client_id . "'";
	$paid_result = mysqli_query($con,$query) or die(mysql_errno() . ":" . mysql_error() . ": Please Contact Your System Administrator");

//echo $query;
$rowcount=mysqli_num_rows($result);
if($rowcount == 0){
	echo "<div> No Record Found !!!!</div>";
}else{
?>
<script id="client" src="<?php echo $url ?>/js/client.js" baseURL='<?php echo $url ?>'   crossorigin="anonymous"></script>


<ul class="nav nav-pills">
  <li class="nav-item">
    <a class="nav-link active"  data-toggle="tab" href="#clientDetails">Client Details</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"  data-toggle="tab" href="#viewTransactionDetails">View Transactions</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"  href="#viewTransactionDetails"  data-toggle="modal" data-target="#addTransaction">Add Transactions</a>
  </li>
 </ul>
 <div class="tab-content">
 <div  id="viewTransactionDetails" class="tab-pane fade">
  <table  class="table table-striped" >
  <thead>
  <th>Transaction Date</th>
  <th>Transaction Amount</th>
  <th>Total Payment</th>
  <th>Next Appointment Date</th>
  </thead>
            <tbody>
    
  <?php
            while ($row = mysqli_fetch_array($paid_result)) {
               // $due = $row['total'] - $row['paid'];
         
echo '<tr><td>';
echo $row['date'];echo '</td>';
echo '<td>Rs ';echo $row['paid'];echo '</td>';
echo '<td>Rs ';echo $row['total_payment'];echo '</td>';
echo '<td>';echo $row['next_appointment'];echo '</td></tr>';
			
			}?>
 
 
 </tbody>
 </table>
 
 </div>
<div id="clientDetails" class="tab-pane in active">
<form action="existingclientaddamount.php" id="updateClientDetails" method="GET">
    <table  class="table table-striped" >
            <tbody>
            <?php
            while ($row = mysqli_fetch_array($result)) {

                $due = $row['total'] - $row['paid'];
            ?>
			
                <tr>
                    <td>Client ID</td>
                    <td nowrap><input readonly class="form-control" type="text" name="client_id" value="<?php echo $row['client_id']; ?>" ></td>
					<td>Client Name</td>
                    <td nowrap><?php echo $row['client_name']; ?></td>
                </tr>
                <tr>
                    
                </tr>
                <tr>
                    <td>Age</td>
                    <td nowrap><?php echo $row['age']; ?></td>
					<td>Phone Number</td>
                    <td nowrap><?php echo $row['phone_no']; ?></td>
                </tr>
				<td>Address</td>
                    <td nowrap><?php echo $row['address']; ?></td>
				    <td> Status </td>
                    <td nowrap>
					<?php $clientStatus =$row['status']; ?>
						<select name="status">
							<option value="">---Select---</option>
							<option value="Active" <?php if(strcasecmp($clientStatus, 'Active') == 0){echo 'selected';} ?>>Active</option>
							<option value="Final"  <?php if(strcasecmp($clientStatus, 'Final') == 0){echo 'selected';} ?>>Final</option>
						</select> 
					</td>
                <tr>
                    <td> Problem Description </td>
                    <td nowrap><input  class="form-control" type="text" name="problem" value="<?php echo $row['problem']; ?>" > </td>
					<td> Prescription </td>
                    <td nowrap><input  class="form-control" type="text" name="refer" value="<?php echo $row['refer']; ?>" > </td>
                </tr>

                
                <tr>
                    <td>Doctor's Reference</td>
                    <td nowrap>
					<input  class="form-control" type="text" name="dr_refer" value="<?php echo $row['dr_refer']; ?>" > </td>
					
               
			<td><button type="button" class="btn btn-primary btn-sm updateClientDetails-submit" >Update Client Details</button></td></tr>

                <tr>
                    <td nowrap>Total Due</td>
                    <td nowrap><?php echo $row['total']; ?></td>
                    <td nowrap>Total Paid</td>
                    <td nowrap><?php echo $row['paid']; ?></td>
                </tr>


                <tr>
                    <td no wrap>Payment Due</td>
                    <td nowrap><?php echo $due ?></td>
                </tr>

            <?php } ?>

        </tbody>
    </table>
</center><br><br><br>
<script language="javascript" type="text/javascript" src="datetimepicker.js">
        </script>
   </form>
  </div> 
</div>  
</center>
<?php
}  } else {
?>
                    <center><h2>Existing Client Details</h2>
                        <form name="frm" action="existingclient.php" method="POST">
<div class="col-md-16 text-center">                         
						 <table class="table table-striped">
                                <thead>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Enter Client id</td>
                                        <td><input type="text" name="client_id" value="" size="100" /></td>

                                    </tr>
                                    
                                </tbody>
                            </table>
							</div>
                            <div class="text-center"><input  class="btn btn-secondary btn-sm" type="reset" value="Reset" />
                        <input class="btn btn-primary btn-sm" type="submit" value="Submit Details" /></div>



                        </form></center>
<?php } ?>
<?php include '../footer.php'; ?>

<!--Modal for Add Employee-->
<div class="modal" id="addTransaction">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Transaction Details</h4>
        <!--button type="button" class="close" data-dismiss="modal">&times;</button-->
      </div>

      <!-- Modal body -->
      <div class="modal-body modal-lg">
        <form id="add-transaction-form" method="GET" >

           <table class="table table-striped">
            <tbody>
                <tr>
                    <td nowrap>Total Amount</td>
                    <td><input type="text" name="total" value="0" /></td>
                </tr>
                <tr>
                    <td nowrap>Amount Paid</td>
                    <td><input type="text" name="amt" value="" /></td>
                </tr>
                <tr>
                    <td nowrap>Next Appointment Date</td>
                    <td><input id="demo3" name="next_appointment" type="text" size="20"><a href="javascript:NewCal('demo3','ddMMyyyy')"><img src="../cal.gif" width="16" height="16" border="0" alt="Pick a date"></a></td>
                </tr>

                <tr>
					<?php echo '<input type="hidden" name="transactionType" value="addTransaction" />' ?>
                    <?php echo '<input class="client_id" type="hidden" name="client_id" value="' . $client_id . '" />' ?>
                            </tbody>
        </table>                     
        </form>
    </center>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
	  <input type="submit" class="btn btn-primary addTransaction-submit" name="addTransaction" value="Submit Details" />
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
  
  
  