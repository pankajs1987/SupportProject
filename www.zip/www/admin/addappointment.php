<html>
    <head>
        <script language="javascript" type="text/javascript" src="datetimepicker.js">


        </script>


    </head>
    <body>

        <?php
        include 'menu.php';
        include '../db.php';

        if (isset($_REQUEST['client_id'])) {
            $client_id = $_REQUEST['client_id'];
            $date = $_REQUEST['date'];
            if ($client_id != "" || $client_id != null) {
                $query = "insert into paid (client_id,date) values (" . $client_id . ",STR_TO_DATE('" . $date . "','%d-%c-%Y'))";
                $result = mysql_query($query, $con) or die(mysql_errno().":".  mysql_error().'Could not Execute Query');
                $nrow = 0;
                $nrow = mysql_affected_rows();
                if ($nrow == 1) {
                    echo 'Record Added Successfully';
                }
            }
        ?>



            <center>
<?php
            echo'<h2>Client Detail Please Note Down the Transaction id For Further Correspondence</h2>';



            $query = "Select * from paid order by id desc";
            $result = mysql_query($query, $con) or die("Can not execute Select Statement");
            while ($row = mysql_fetch_array($result)) {
?>

                <table border="2">
                    <tr>
                        <td>
                            Transaction id  ::
                        </td>
                        <td>
<?php echo $row['id']; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Client id  ::
                        </td>
                        <td>
<?php echo $row['client_id']; ?>
                    </td>
                </tr>

                <tr>
                    <td>
                        Appointment Date (yyyy-mm-dd)  ::
                    </td>
                    <td>
<?php echo $row['date']; ?>
                    </td>
                </tr>


            </table>

<?php break;
            } ?>

        </center>
        <?php } ?>
        <br><br><br><br><br><br>


        <form method="get" action="addappointment.php" ><center>
                <table border="1">
                    <thead>
                        <tr>

                            <th>Add Detail For Client Appointment (Only Existing Client).</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Enter Client ID :</td>
                            <td>
                                <input name="client_id" type="text" maxlength="100" >
                                <a href="client_detail.php" target="_blank">For Client Detail Click here</a>
                            </td>
                        </tr>
                        <tr>
                            <td>Enter Date :</td>
                            <td>
                                <input id="demo3" name="date" type="text" size="25"><a href="javascript:NewCal('demo3','ddMMyyyy')"><img src="../cal.gif" width="16" height="16" border="0" alt="Pick a date"></a>

                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><center><input type="submit" value="Submit">    </center></td>
                        </tr>
                    </tbody>
                </table>
            </center>
        </form>
    </body>
</html>
<?php include '../footer.php'; ?>