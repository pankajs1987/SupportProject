<?php
        
        include '../common/menu.php';
        include '../db.php';
        include '../common/today_appointmentflash.php';
?>
<?php include '../footer.php'; ?>