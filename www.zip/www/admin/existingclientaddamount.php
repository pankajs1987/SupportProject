<?php
include_once '../config/database.php';
include_once '../objects/Paid.php';
include_once '../objects/Client.php';

//Db conn and instances
$database = new Database();
$db       = $database->getConnection();

$paid   = new Paid($db);
$client = new Client($db);

//set Id and values of product to be editedlaun
$paid->client_id        = $_REQUEST['client_id'];
$client->client_id      = $_REQUEST['client_id'];
$client->problem        = $_REQUEST['problem'];
$client->refer          = $_REQUEST['refer'];
$client->dr_refer       = $_REQUEST['dr_refer'];
$paid->total_payment    = $_REQUEST['total'];
$transactionType     = $_REQUEST['transactionType'];
$paid->paid             = $_REQUEST['amt'];
$paid->date             = date('d-m-Y', time());
$paid->next_appointment = $_REQUEST['next_appointment'];

if($transactionType==="addTransaction"){
	if ($paid->create()) {
        echo '{';
        echo '"message": "Unable to Update Amount."';
        echo '}';
        // header('Location:existingclient.php');
    }
}else if($transactionType==="viewTransaction"){
	if ($paid->create()) {
        echo '{';
        echo '"message": "Unable to Update Amount."';
        echo '}';
        // header('Location:existingclient.php');
    }
}else{}
?>