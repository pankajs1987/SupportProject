<?php
include '../../common/menu.php';
include '../../db.php';
$query="select * from employee where ongoing=1";
$result=  mysqli_query($con,$query);
if (!$result) {
   printf("Errormessage: %s\n", $mysqli->error);
}
?><center>
    <h2></h2>
    <table  class="table table-striped">
        <thead>
		<tr>
                <th colspan=6>Employee Details </th>
                <th colspan=2><button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#AddEmployee">Add Employee</button> </th>
                
     
            </tr>
            <tr>
                <th>Employee id</th>
                <th>Employee Name</th>
                <th>Basic</th>
                <th>Incentive</th>
                <th>Joining Date</th>
                <th>Salary</th>
                <th>Adjustment</th>
				<th>Action</th>
            </tr>
        </thead>
        <tbody>

<?php
$tmpCount = 1;
while($row=  mysqli_fetch_array($result))
{
    ?>
            <tr>
                <td><?php echo $row['emp_id']; ?></td>
                <td><?php echo $row['emp_name']; ?></td>
                <td><?php echo $row['basic']; ?></td>
                <td><?php echo $row['incentive']; ?></td>
                <td><?php echo $row['joining_date']; ?></td>
                <td><a class="btn btn-primary btn-sm" href="/admin/Salary/index.php?emp_id=<?php echo $row['emp_id'] ?>" >Details</a>
                <td><a class="btn btn-secondary btn-sm" href="/admin/Employeeadjustment/index.php?emp_id=<?php echo $row['emp_id'] ?>" >Details</a></td>
				<td><a class="btn btn-danger btn-sm" href="/admin/employee/delete_employee.php?emp_id=<?php echo $row['emp_id'] ?>" >Delete</a></td>
                
            </tr>



    <?php
}
?>
</tbody>
    </table>
</center>
<!--Modal for Add Employee-->
<div class="modal" id="AddEmployee">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Employee</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body modal-lg">
        <form id="add-employee-form" action="addemployee.php" method="POST">

            <table  class="table table-striped">
                <tbody>
                <tr>
                        <td>Employee Id</td>
                        <td><input type="text" name="emp_id" value="" /></td>
                    </tr>
                    <tr>
                        <td>Employee Name</td>
                        <td><input type="text" name="emp_name" value="" /></td>
                    </tr>
                    <tr>
                        <td>Basic</td>
                        <td><input type="text" name="basic" value="" /></td>
                    </tr>
                    <tr>
                        <td>incentive</td>
                        <td><input type="text" name="incentive" value="0" /></td>
                    </tr>
                    <tr>
                        <td>Joining Date</td>
                        <td><input id="demo3" name="date" type="text" size="25"><a href="javascript:NewCal('demo3','ddMMyyyy')"><img src="../../cal.gif" width="16" height="16" border="0" alt="Pick a date"></td>
                                </tr>
                </tbody>
            </table>
            
                        

        </form>
    </center>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
	  <input type="submit" class="btn btn-primary addEmployee-submit" value="Submit Details" />
        <button type="button" class="btn btn-danger addEmployee-close" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

<!--Modal for Add Employee-->


<?php include '../../footer.php'; ?>