<?php
include 'menu.php';
include '../db.php';
if (isset($_REQUEST['emp_id'])) {
    $emp_id = $_REQUEST['emp_id'];
    $date = $_REQUEST['date'];
    $basic=$_REQUEST['basic'];
    $advance=$_REQUEST['advance'];
    $incentive=$_REQUEST['incentive'];
    $deduction=$_REQUEST['deduction'];
	$remark=$_REQUEST['remark'];
	echo $remark;
     $query="insert into salary (emp_custom_id,salary_month,basic,advance,incentive,deduction,remark,ongoing) value ('".$emp_id."','".$date."',".$basic.",".$advance.",".$incentive.",".$deduction.",'".$remark."',1)";

    $result=mysqli_query($con,$query) or die(mysql_errno().mysql_error()." :: Salary Already Paid to this employee for this particular month");
if($result)
{ // header('location:addsalary.php');
  
}
}
?>
<?php include '../footer.php'; ?>