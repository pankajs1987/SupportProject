<?php
include '../../common/menu.php';
include '../../db.php';

if(isset ($_REQUEST['emp_id']))
{
$emp_id=$_REQUEST['emp_id'];

$query="select s.emp_custom_id as emp_id,e.emp_name as emp_name,month(s.salary_month) as month,year(s.salary_month) as year,s.basic as basic,s.incentive as incentive,s.deduction as deduction,s.advance as advance,s.remark as remark from salary s,employee e where  s.emp_custom_id=e.emp_id and s.ongoing=1 and e.ongoing=1 and s.emp_custom_id='".$emp_id."'";
$result=  mysqli_query($con,$query);

 if ($con->error) {
    try {    
        throw new Exception("MySQL error $con->error <br> Query:<br> $query", $con->errno);    
    } catch(Exception $e ) {
        echo "Error No: ".$e->getCode(). " - ". $e->getMessage() . "<br >";
        echo nl2br($e->getTraceAsString());
    }
}
?><center>
    <h2>Employee Details with Over all salary Details</h2>
    <br>
<table  class="table table-striped">
    <thead>
        <tr>
            <th>Employee ID</th>
            <th>Employee Name</th>
            <th>Month-Year</th>
            <th>Basic</th>
            <th>Incentive</th>
            <th>Remark</th>
            <th>Get Adjustment Details</th>
        </tr>
    </thead>
    <tbody>


<?php
while($row=mysqli_fetch_array($result))	
{?>
        <tr>
    <td><?php echo $row['emp_id'];  ?></td>
                <td><?php echo $row['emp_name'];  ?></td>
                <td><?php echo $row['month'].'-'.$row['year'];  ?></td>
                <td><?php echo $row['basic'];  ?></td>
                <td><?php echo $row['incentive'];  ?></td>
				<td><?php echo $row['remark'];  ?></td>
                <td><a href="/admin/Employeeadjustment/index.php?emp_id=<?php echo $row['emp_id']?>&month=<?php echo $row['month'].'-'.$row['year']?>" >Get Adjustment Details</a></td>
        </tr>


    <?php
 
}


?>
<a href="" onclick="window.close()">Close</a>  <?php

}
else
    {?>
    </tbody>

</table>
    

</center>

<form action="getdetailsalary.php" method="get">
    <center>
        <table  class="table table-striped">
            <tbody>
                <tr>
                    <td>Enter Employee id</td>
                    <td><input type="text" name="emp_id" value="" /></td>
                </tr>
               
            </tbody>
        </table>
        <div class="col-md-16 text-center"><input type="reset" value="Reset" />
                        <input type="submit" value="Submit Details" /></div>


    </center>

    </center>
</form>

<?php 

}  ?>