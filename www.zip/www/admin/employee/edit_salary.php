<?php
include 'menu.php';
include '../db.php';

if (isset($_REQUEST['emp_id'])) {
    $emp_id = $_REQUEST['emp_id'];
    $year = $_REQUEST['year'];
    $month = $_REQUEST['month'];
    echo '<center><h2>Update Salary For the Month of '.$month.'-'.$year.'</h2></center>';
    $query = "select * from employee where ongoing=1 and emp_id='$emp_id'";
    $result = mysqli_query( $con,$query);
    $row = mysqli_fetch_array($result);
?><form action="salaryupdated.php" method="POST">
    <input type="hidden" name="emp_id" value=<?php echo'"'.$emp_id.'"';?> />
	<input type="hidden" name="month" value="<?php echo $month;?>" />
	<input type="hidden" name="year" value="<?php echo $year;?>" />
    <input type="hidden" name="date" value=<?php echo'"'.$year.'-'.$month.'-7"';?> />
<center>
        <table class="table table-striped">
            <tbody>
                <tr>
                    <td>Employee ID</td>
                    <td><?php echo $row['id']; ?></td>
                </tr>
                <tr>
                    <td>Employee Name</td>
                    <td><?php echo $row['emp_name']; ?></td>
                </tr>
                <tr>
                    <td>Basic : </td>
                    <td><?php echo'<input type="text" name="basic" value="' . $row['basic'] . '"'; ?></td>
                </tr>
                <tr>
                    <td>Incentive : </td>
                    <td><?php echo'<input type="text" name="incentive" value="' . $row['incentive'] . '"'; ?></td>
                </tr>
                <tr>
                    <td>Advance</td>
                    <td><?php echo'<input type="text" name="advance" value="0"'; ?></td>
                </tr>

                <tr>
                    <td>Deduction</td>
                    <td><?php echo'<input type="text" name="deduction" value="0"'; ?></td>
                </tr>
               

				<tr>
                    <td></td>
                    <td><input type="submit" value="Submit" /></td>
                </tr>

            </tbody>
        </table>
</center>
</form>

<?php
} else {
?><h2><center>Update Salary for Employee</center></h2>
    <form action="edit_salary.php" method="POST">
        <center>
            <table   class="table table-striped">
                <tbody>
                    <tr>
                        <td>Select Month :</td>
                        <td><select name="month">
                                <option value="Select" selected>Select</option>
                                <option value="1">January</option>
                                <option value="2">February</option>
                                <option value="3">March</option>
                                <option value="4">April</option>
                                <option value="5">May</option>
                                <option value="6">June</option>
                                <option value="7">July</option>
                                <option value="8">August</option>
                                <option value="9">September</option>
                                <option value="10">October</option>
                                <option value="11">November</option>
                                <option value="12">December</option>
                            </select></td>
                    </tr>
                    <tr>
                        <td>Select Year :</td>
                        <td><select name="year">
                                <option value="Select" selected>Select</option>
                                <option value="2018">2018</option>
                                <option value="2019">2019</option>
                                <option value="2020">2020</option>
                            </select></td>
                    </tr>


                    <tr>
                        <td>Enter Employee ID</td>
                        <td><input type="text" name="emp_id" value="" /><a href="empid.php" target="_new"> (Forgot id Click Here)</a></td>
                    </tr>
                    <tr>
                        <td><input type="reset" value="Reset" /> </td>
                        <td><input type="submit" value="Submit" /></td>
                    </tr>

                </tbody>
            </table>
        </center>

    </form>
<?php } ?>
<?php include '../footer.php'; ?>