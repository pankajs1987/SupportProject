<?php
include '../../common/menu.php';
include '../../db.php';

if (isset($_REQUEST['emp_name'])) {
    $emp_name = $_REQUEST['emp_name'];
    $emp_id = $_REQUEST['emp_id'];
    $basic = $_REQUEST['basic'];
    $incentive = $_REQUEST['incentive'];
    $date = $_REQUEST['date'];

    $query = "insert into employee (emp_id,emp_name,basic,incentive,joining_date,ongoing) value('" . $emp_id . "','" . $emp_name . "'," . $basic . "," . $incentive . ",STR_TO_DATE('".$date."','%d-%c-%Y'),1)";
    $result = mysqli_query($con,$query) or die(mysqli_errno() . ":" . mysql_error() . " :: Fatal Error Please Contact Your Administrator");
} else {
?>


    <script language="javascript" type="text/javascript" src="datetimepicker.js"> </script>

    <center><h2>Add Employee</h2>
        <form action="addemployee.php" method="POST">

            <table  class="table table-striped">
                <tbody>
                <tr>
                        <td>Employee Id</td>
                        <td><input type="text" name="emp_id" value="" /></td>
                    </tr>
                    <tr>
                        <td>Employee Name</td>
                        <td><input type="text" name="emp_name" value="" /></td>
                    </tr>
                    <tr>
                        <td>Basic</td>
                        <td><input type="text" name="basic" value="" /></td>
                    </tr>
                    <tr>
                        <td>incentive</td>
                        <td><input type="text" name="incentive" value="0" />(Update,if Paying)</td>
                    </tr>
                    <tr>
                        <td>Joining Date</td>
                        <td><input id="demo3" name="date" type="text" size="25"><a href="javascript:NewCal('demo3','ddMMyyyy')"><img src="../../cal.gif" width="16" height="16" border="0" alt="Pick a date"></td>
                                </tr>
                </tbody>
            </table>
            <div class="col-md-16 text-center"><input type="reset" value="Reset" />
                        <input type="submit" value="Submit Details" /></div>

        </form>
    </center>
<?php } ?>
<?php include '../../footer.php'; ?>