<?php
include 'menu.php';
include '../db.php';
if (isset($_REQUEST['emp_id'])) {
    $emp_id = $_REQUEST['emp_id'];
    $date = $_REQUEST['date'];
	$month = $_REQUEST['month'];
	$year = $_REQUEST['year'];
    $basic=$_REQUEST['basic'];
    $advance=$_REQUEST['advance'];
    $incentive=$_REQUEST['incentive'];
    $deduction=$_REQUEST['deduction'];
     $query="update salary set basic=".$basic.",advance=".$advance.",incentive=".$incentive.",deduction=".$deduction." where emp_id=".$emp_id." and month(salary_month)='".$month."' and year(salary_month)='".$year."'";

    $result=mysql_query($query,$con) or die(mysql_errno().mysql_error()." :: Salary Can not be updated for this particular month of this employee");
if($result)
{header('location:edit_salary.php');

}
}
?>
<?php include '../footer.php'; ?>