<?php
include '../../common/menu.php';
include '../../db.php';


if(isset ($_REQUEST['action']) && isset ($_REQUEST['id']))
{   
	$emp_id=$_REQUEST['id'];
    $query="update employee set ongoing=0 where id=".$emp_id;
    $result = mysqli_query($con,$query);
	echo "<h2>Employee Deleted Successfully</h2>";
}
else if(isset ($_REQUEST['emp_id']) && !isset($_REQUEST['action']))
{
    $emp_id=$_REQUEST['emp_id'];
    $query="select * from employee where ongoing=1 and emp_id='".$emp_id."'";
   $result = mysqli_query($con,$query);
    ?><center>
<h2>Employee Details </h2>
<table  class="table table-striped">
<thead>
    <tr>
        <th>Employee id</th>
        <th>Employee Name</th>
        <th>Basic</th>
        <th>Incentive</th>
        <th>Joining Date</th>
        <th>Delete</th>
    </tr>
</thead>
<tbody>



 <?php
    while ($row = mysqli_fetch_array($result))
    {
        ?>
<tr >
<form name="f" action="delete_employee.php">
    <td><input type="hidden" name="id" value="<?php echo $row['id']; ?>"> <?php echo $row['id']; ?></td>
    <td><?php echo $row['emp_name']; ?></td>
    <td><?php echo $row['basic']; ?></td>
    <td><?php echo $row['incentive']; ?></td>
    <td><?php echo $row['joining_date']; ?></td>
    <td><input type="submit" value="Delete" name="action" class="btn btn-danger btn-sm"/> </td>
    </form>
</tr>

        <?php } }

        ?>


          