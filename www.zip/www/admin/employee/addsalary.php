<?php
include '../../common/menu.php';
include '../../db.php';
$emp_id="";


//To write to a log file and make a new one each day, you could use date("j.n.Y") as part of the filename.

//Something to write to txt log

if (isset($_REQUEST['addSalary']) && isset($_REQUEST['emp_id'])) {
	 $emp_id = $_REQUEST['emp_id'];
    $date = $_REQUEST['date'];
    $basic=$_REQUEST['basic'];
    $advance=$_REQUEST['advance'];
    $incentive=$_REQUEST['incentive'];
    $deduction=$_REQUEST['deduction'];
	$remark=$_REQUEST['remark'];
//	echo $remark;

     $query="insert into salary (emp_custom_id,salary_month,basic,advance,incentive,deduction,remark,ongoing) value ('".$emp_id."','".$date."',".$basic.",".$advance.",".$incentive.",".$deduction.",'".$remark."',1)";
file_put_contents('./log_'.date("j.n.Y").'.log', $query, FILE_APPEND);

//echo $query;
    $result=mysqli_query($con,$query) or die(mysql_errno().mysql_error()." :: Salary Already Paid to this employee for this particular month");//
	//header('location:/admin/empid.php');
}

if (isset($_REQUEST['emp_id'])){
	$emp_id = $_REQUEST['emp_id'];
}

if ($emp_id !="" || $emp_id !=null ) {
    $emp_id = $_REQUEST['emp_id'];
    $query = "select * from employee where ongoing=1 and emp_id='$emp_id'";
    $result = mysqli_query($con,$query);
    $row = mysqli_fetch_array($result);
?><form action="addsalary.php?emp_id=<?php echo $row['emp_id']; ?>" method="GET">
<center>
        <table  class="table table-striped">
		<thead><th colspan=4>Employee Salary Details</th></thead>
            <tbody>
                <tr>
                    <td>Employee ID</td>
                    <td><?php echo $row['emp_id']; ?></td>
                    <td>Employee Name</td>
                    <td><?php echo $row['emp_name']; ?></td>
                </tr>
                 <tr>
                        <td>Select Month :</td>
                        <td><select name="month">
                                <option value="Select" selected>Select</option>
                                <option value="1">January</option>
                                <option value="2">February</option>
                                <option value="3">March</option>
                                <option value="4">April</option>
                                <option value="5">May</option>
                                <option value="6">June</option>
                                <option value="7">July</option>
                                <option value="8">August</option>
                                <option value="9">September</option>
                                <option value="10">October</option>
                                <option value="11">November</option>
                                <option value="12">December</option>
                            </select></td>
                        <td>Select Year :</td>
                        <td>
						<?php
// set start and end year range
								$yearArray = range(2014, date('Y'));
						?>
<!-- displaying the dropdown list -->
							<select name="year">
									<option value="">Select Year</option>
							<?php
    foreach ($yearArray as $year) {
        // if you want to select a particular year
        $selected = ($year == date('Y')) ? 'selected' : '';
        echo '<option '.$selected.' value="'.$year.'">'.$year.'</option>';
    }
    ?>
</select></td>
                    </tr>

                <tr>
                    <td>Basic : </td>
                    <td><?php echo'<input type="text" name="basic" value="' . $row['basic'] . '"'; ?></td>
                </tr>
                <tr>
                    <td>Incentive : </td>
                    <td><?php echo'<input type="text" name="incentive" value="' . $row['incentive'] . '"'; ?></td>
                </tr>
                <tr>
                    <td>Advance</td>
                    <td><?php echo'<input type="text" name="advance" value="0"'; ?></td>
                </tr>

                <tr>
                    <td>Deduction</td>
                    <td><?php echo'<input type="text" name="deduction" value="0"'; ?></td>
                </tr>
				<tr>
                    <td>Remark</td>
                    <td><?php echo'<input type="text" name="remark" '; ?></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" name="addSalary" value="Submit" /></td>
                </tr>

            </tbody>
        </table>
</center>
</form>

<?php
} 
?>
  
<?php include '../../footer.php'; ?>