 <?php
 
include 'menu.php';
        include '../db.php';
       
        if (isset($_GET['pageno'])) {
            $pageno = $_GET['pageno'];
        } else {
            $pageno = 1;
        }

         $no_of_records_per_page = 30;
        $offset = ($pageno-1) * $no_of_records_per_page;
		$query = "SELECT * FROM client";
		$where_condition="";
		$whereClause = "";
		$client_name="";
		$phone_no="";
		$dr_refer="";
		if (isset($_GET['client_name']) && $_GET['client_name'] <> "") {
			$where_condition .=" where ";
			$whereClause ="C";
			$where_condition .= "client_name like '%".$_GET['client_name']."%'";
			$client_name=$_GET['client_name'];
        }
		if (isset($_GET['phone_no'])  && $_GET['phone_no'] <> "") {
			if($whereClause ==="C"){
				$where_condition .= " or";	
			}else{
				$whereClause ="CP";
				$where_condition .=" where ";
			}
			$where_condition .= " phone_no like '%".$_GET['phone_no']."%'";
			$phone_no=$_GET['phone_no'];
        }
		if (isset($_GET['dr_refer'])  && $_GET['dr_refer'] <> "") {
			if($whereClause ==="CP" || $whereClause ==="C"){
				$where_condition .= " and";	
			}else{
				$where_condition .=" where ";
			}
			$where_condition .= " dr_refer like '%".$_GET['dr_refer']."%'";
			$dr_refer=$_GET['dr_refer'];
        }		
		$query .=$where_condition;
		$query .= " order by date desc LIMIT $offset,$no_of_records_per_page;";
		$total_pages_sql = "SELECT COUNT(*) FROM client";
		$total_pages_sql .= $where_condition;
        $result = mysqli_query($con,$total_pages_sql);
        $total_rows = mysqli_fetch_array($result)[0];
        $total_pages = ceil($total_rows / $no_of_records_per_page);
        mysqli_free_result($result);
		echo $query;
        ?>
    <center>


 <form action="<?php echo $absolute_url?>" method="GET">

        <center>
            <table class="table table-striped">
			<th colspan=6> Search Customer</th>
                <tbody>
                    <tr>
                        <td>Name </td>
                        <td><input type="text"  name="client_name" value="<?php echo $client_name ?>" size="50"  /></td>
						<td>Phone Number </td>
                        <td><input type="text"  name="phone_no" value="<?php echo $phone_no ?>" size="15"  /></td>
						<td>Refered By </td>
                        <td><input type="text"  name="dr_refer" value="<?php echo $dr_refer ?>" size="15"  /></td>
                    </tr>
                   
                </tbody>
            </table>

			<div class="col-md-16 text-center">
			<input type="reset" value="Reset" />
            <input type="submit" value="Submit Details" /></div>

        </center>


    </form>

	

<table class="table table-striped"  >
    <thead>
        <tr>
            <th  nowrap>Client ID </th>
            <th  nowrap>Client Name</th>
            <th  nowrap>Doctor's Reference</th>
			<th  nowrap>Phone Number</th>
            <th  nowrap>Date of Joining</th>
        </tr>
    </thead>
<tbody id="client_details">
                <?php
                $query_result= mysqli_query($con, $query);
                while($row=mysqli_fetch_assoc($query_result)) {
        ?><tr>
            <td  nowrap><?php echo $row['client_id']; ?></td>
            <td  nowrap><?php echo $row['client_name']; ?></td>
            <td  nowrap><?php echo $row['dr_refer']; ?></td>
			<td  nowrap><?php echo $row['phone_no']; ?></td>
            <td  nowrap><?php echo $row['date']; ?></td>
        </tr>
          <?php
          
                }
            


           ?>


    </tbody>
</table>
<div class="float-right"> 
    <ul class="pagination float-right">
        <li><a href="?pageno=1">First</a></li>
        <li class="<?php if($pageno <= 1){ echo 'disabled'; } ?>">
            <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?client_name=".$client_name."&phone_no=".$phone_no."&dr_refer=".$dr_refer."&pageno=".($pageno - 1); } ?>">Prev</a>
        </li>
        <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">
            <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?client_name=".$client_name."&phone_no=".$phone_no."&dr_refer=".$dr_refer."&pageno=".($pageno + 1); } ?>">Next</a>
        </li>
        <li><a href="<?php echo"?client_name=".$client_name."&phone_no=".$phone_no."&dr_refer=".$dr_refer."&pageno=".$total_pages;?>">Last</a></li>
    </ul>
<div>
 </center>
<?php include '../footer.php'; ?>



