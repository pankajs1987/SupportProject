<?php
include 'menu.php';
include '../db.php';
if(isset ($_REQUEST['amount'])){
$precaution=$_REQUEST['precaution'];
$refer=$_REQUEST['refer'];
$client_name=$_REQUEST['client_name'];
$client_id=$_REQUEST['client_id'];
$amount=$_REQUEST['amount'];
$paying=$_REQUEST['paying'];
$date=$_REQUEST['date'];
$status=$_REQUEST['status'];
$query="update client SET amount=".$amount." ,client_name='".$client_name."',status='".$status."',problem='".$precaution."',refer='".$refer."' where client_id='".$client_id."'";
mysqli_query($con,$query) or die(mysql_errno().":".  mysql_error() ."Some Problem has been Occured in Executing Your Query,Please Contact Your System Administrator");
$query1="insert into paid (client_id,total_payment,paid,date) value('".$client_id."',".$amount.",".$paying.",'".$date."')";
mysqli_query($con,$query1) or die(mysql_errno().":".  mysql_error() ."Some Problem has been Occured in Executing Your Query1,Please Contact Your System Administrator");

    echo 'Result Updated,Want to Add More Client Details ';
}
?>
<?php include '../footer.php'; ?>
