<?php
include 'menu.php';
include '../db.php';
?>


    <center><h2>Current Month Salary Detail of Employees</h2>

    <table border="2">
        <thead>
            <tr>
                <th>Employee ID</th>
                <th>Employee Name</th>
                <th>Month</th>
                <th>Basic</th>
                <th>Incentive</th>
                <th>Deduction</th>
                <th>Advance</th>
                <th>View Detail</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $query="select s.emp_id as emp_id,e.emp_name as emp_name,month(s.salary_month) as month,year(s.salary_month) as year,s.basic as basic,s.advance as advance,s.incentive as incentive,s.deduction as deduction from salary s,employee e where  year(s.salary_month)=year(CURDATE()) and month(s.salary_month)=month(CURDATE()) and s.emp_id=e.id and ongoing=1";
$result=  mysqli_query($con,$query,$con);
while($row=  mysql_fetch_array($result)){
            ?>
            <tr>
                <td><?php echo $row['emp_id'];  ?></td>
                <td><?php echo $row['emp_name'];  ?></td>
                <td><?php echo $row['month'].'-'.$row['year'];  ?></td>
                <td><?php echo $row['basic'];  ?></td>
                <td><?php echo $row['incentive'];  ?></td>
                <td><?php echo $row['deduction'];  ?></td>
                <td><?php echo $row['advance'];  ?></td>
                <td><a href="getdetailsalary.php?emp_id=<?php echo $row['emp_id']; ?>" target="_blank" >Fetch Details</a> </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</center>
<?php include '../footer.php'; ?>