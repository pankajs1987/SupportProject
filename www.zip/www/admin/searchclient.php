<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
  "SELECT * FROM client WHERE field1 LIKE ‘%'".$client_name."'%’"
 *  */
include 'menu.php';
 include '../db.php';

if (isset($_REQUEST['client_name'])) {
    $client_name = $_REQUEST['client_name'];
    $query = "SELECT * FROM client WHERE client_name LIKE '%".$client_name."%' or phone_no LIKE '%".$client_name."%'";
    $result = mysqli_query( $con,$query) or die(mysql_errno() . ":" . mysql_error() . ": Please Contact Your System Administrator");
    $nrow = mysqli_num_rows ($result);
    if ($nrow) {
        echo' <center>
        <table   class="table table-striped">
            <thead>
                <tr>
                    <th nowrap>Client ID</th>
                    <th nowrap>Client Name</th>
                    <th nowrap>Phone Number</th>
                    <th nowrap>Status</th>
                    
                </tr>
            </thead>
            <tbody>';


        while ($row = mysqli_fetch_array($result)) {
?>
            <tr>
                <td nowrap><?php echo $row['client_id']; ?></td>
                <td nowrap><?php echo $row['client_name']; ?></td>
                <td nowrap><?php echo $row['phone_no']; ?></td>
                <td nowrap><?php echo $row['status']; ?></td>

            </tr>


<?php
        }
    } else {
        echo'<center><blink><h2>No Result Found Enter Valid Name</h2></blink></center>';
    }
?>
    </tbody>
    </table>

    </center>

<?php
} else {
?>

    <form action="searchclient.php">

        <center>
            <table class="table table-striped">
                <tbody>
                    <tr>
                        <td>Enter Client Name/Client Phone Number </td>
                        <td><input type="text" name="client_name" value="" size="50" /></td>
                    </tr>
                   
                </tbody>
            </table>

<div class="col-md-16 text-center"><input type="reset" value="Reset" />
                        <input type="submit" value="Submit Details" /></div>

        </center>


    </form>




<?php
}
?>
