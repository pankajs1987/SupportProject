<?php
include '../common/menu.php';
include '../db.php';

$query="select dr_refer from client group by dr_refer";
$result= mysqli_query($con,$query);
$id=0;
?><center>
<table  class="table table-striped" >
<thead>
<tr>
<th nowrap> Serial Number</th>
<th nowrap>Doctor's Name</th>
<th nowrap>Update Name</th>
<th nowrap>Edit</th>
</tr>
</thead>
<tbody>
    <?php while($row=  mysqli_fetch_array($result)) {  ?>
<tr>
<form name="frm" action="dr_edited.php" method="post">
<td nowrap><?php echo $id;  $id++; ?></td>
<td nowrap><?php echo $row['dr_refer'];?></td>
<input type="hidden" name="dr_old" value="<?php echo $row['dr_refer'];?>" /></td>
<td nowrap><input  type="text" name="dr_new" value="<?php echo $row['dr_refer'];?>" nowrap /></td>
<td nowrap><input  class="btn btn-primary  btn-sm" type="Submit" value="Edit Details" /></td>
</form>
</tr>
<?php }?>
</tbody>
</table>
<?php include '../footer.php'; ?>
</center>

