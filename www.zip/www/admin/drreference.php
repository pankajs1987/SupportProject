
<?php
include '../common/menu.php';
include '../db.php';

if(isset ($_REQUEST['reference']) && $_REQUEST['reference']!='Select' ){
$dr_refer=$_REQUEST['reference'];
//echo $dr_refer;
$query="select * from client where dr_refer='".$dr_refer."'";
$result= mysqli_query($con,$query);
?><center>
<table  class="table table-striped" >
<thead>
<tr>
<th nowrap>Client id</th>
<th nowrap>Client Name</th>
<th nowrap>Problem</th>
<th nowrap>Prescriptions</th>
<th nowrap>Date of Joining</th>
<th nowrap>Status</th>
</tr>
</thead>
<tbody>
    <?php while($row=  mysqli_fetch_array($result)) {?>
<tr>
<td nowrap><?php echo $row['client_id'];?></td>
<td nowrap><?php echo $row['client_name'];?></td>
<td nowrap><?php echo $row['problem'];?></td>
<td nowrap><?php echo $row['refer'];?></td>
<td nowrap><?php echo $row['date'];?></td>
<td nowrap><?php echo $row['status'];?></td>
</tr>
<?php } ?>
</tbody>
</table></center>
<?php }  else{?>
<form name="frm" action="drreference.php" method="POST">
    <center>

        <table class="table table-striped">
            <tbody>
                <tr>
                    <td>Select Doctor</td>
                    <td><select name="reference">
                            <option>Select</option>
<?php
$query="select distinct dr_refer from client group by dr_refer";
$result=mysqli_query($con,$query);
while($row=  mysqli_fetch_array($result))
{?>

                            <option value="<?php echo $row['dr_refer']; ?>"><?php echo $row['dr_refer']; ?></option>
<?php }?>
                        </select></td>
                </tr>
            </tbody>
        </table>

<div class="col-md-16 text-center"><input class='btn btn-secondary btn-sm' type="reset" value="Reset" />
                        <input type="submit" class='btn btn-primary btn-sm' value="Submit Details" /></div>


    </center>
<?php } ?>

</form>