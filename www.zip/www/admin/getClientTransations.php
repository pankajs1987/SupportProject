<?php
include '../db.php';
$query = "SELECT * FROM paid WHERE client_id = '" . $_GET["client_id"] . "'";
echo "Hello From Ajax";

?>
</div>