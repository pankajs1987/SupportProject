<?php
include '../common/menu.php';
include '../db.php';


if (isset($_REQUEST['client_id'])) {
    $client_id = $_REQUEST['client_id'];
    $query = "update client set status='DELETE' WHERE client_id='".$client_id."'";
     mysqli_query($con,$query) or die(mysql_errno() . mysql_error());
     $query1="UPDATE paid set renew=0 where client_id='".$client_id."'";
     mysqli_query($con,$query1) or die(mysql_errno() . mysql_error());
    //$result = mysql_query($query, $con) or die(mysql_errno().":".  mysql_error() .": Please Contact Your System Administrator");
  echo'<center><blink><h2>Client Deleted Successfully</h2></blink></center>';

?>

    <?php
}

else{
   ?>

        <form action="deleteclient.php">

            <center>
                <table   class="table table-striped">
                        <tbody>
                            <tr>
                                <td>Enter Client id to Delete</td>
                                <td><input type="text" name="client_id" value="" size="10" /></td>
                            </tr>
                        </tbody>
                    </table>



            </center>
<div class='modal-footer'>
<input type="reset" value="Reset" class="btn btn-secondary btn-sm"/>
                                <td><input type="submit" class='btn btn-primary btn-sm' value="Submit Details" />
</div>

    </form>

    <?php }
    ?>
