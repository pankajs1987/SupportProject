 <?php
include '../../common/menu.php';
include '../../db.php';

if ($_GET['id']) {
    $id           = $_GET['id'];
    $salary_month = $_GET['salary_month'];
    
    $sql    = "SELECT s.emp_custom_id,e.emp_name,date_format(salary_month,'%d-%b-%Y') as transaction_date,
    date_format(salary_month,'%b-%Y') as salary_month,s.basic,s.incentive,s.deduction,s.advance,
    s.remark FROM salary s join employee e on s.emp_custom_id= e.emp_id WHERE emp_custom_id='$id' and salary_month=STR_TO_DATE('$salary_month','%d-%b-%Y') ";
    //    echo $sql;
    $result = $con->query($sql);
    
    $data = $result->fetch_assoc();
    
    $con->close();
    
?>

<body>

<fieldset>
    <legend>Salary Update for Month of <?php
    echo $data['salary_month'];
?></legend>
    <script language="javascript" type="text/javascript" src="../datetimepicker.js">
    </script>
    <form action="/admin/salary/action/update.php" method="post">
        
        <table  class="table table-striped">
            <tr>
                <th>Employee Id</th>
                <td>
                <?php
    echo '<input type="text" readonly name="emp_id"  value="' . $data['emp_custom_id'] . '"';
?>
               
                </td>
            
                <th>Employee name</th>
                <td><?php
    echo $data['emp_name'];
?></td>
            </tr>    
            <tr>
                        <td>Select Month :</td>
                        <td>
                        <select name="month" size='1'>
    <?php
    for ($i = 0; $i < 12; $i++) {
        $time  = strtotime(sprintf('%d months', $i));
        $label = date('F', $time);
        $value = date('n', $time);
        echo "<option value='$value'>$label</option>";
    }
?>
</select></td>
                        
                        
                             <td>Select Year
                        <?php
    // set start and end year range
    $yearArray = range(2014, date('Y'));
?>
<!-- displaying the dropdown list -->
                    </td>
					<td>        <select name="year">
                                    <option value="">Select Year</option>
                            <?php
    foreach ($yearArray as $year) {
        // if you want to select a particular year
        $selected = ($year == date('Y')) ? 'selected' : '';
        echo '<option ' . $selected . ' value="' . $year . '">' . $year . '</option>';
    }
?>
</select></td>
                    </tr>
            
            
            
            <tr>

                    <td>Basic : </td>
                    <td><?php
    echo '<input type="text" name="basic" value="' . $data['basic'] . '"';
?></td>
                    <td>Incentive : </td>
                    <td><?php
    echo '<input type="text" name="incentive" value="' . $data['incentive'] . '"';
?></td>
                </tr>
                <tr>
                    <td>Advance</td>
                    <td><?php
    echo '<input type="text" name="advance"  value="' . $data['advance'] . '"';
?></td>
                    <td>Deduction</td>
                    <td><?php
    echo '<input type="text" name="deduction"  value="' . $data['deduction'] . '"';
?></td>
                </tr>
               <tr>
                    <td>Remark</td>
                    <td colspan = 3><?php
    echo '<input type="textarea" name="remark"  value="' . $data['remark'] . '"';
?></td>
                    
                </tr>
              

        </table>
        <!-- Modal footer -->
      <div class="modal-footer">
      <?php
    echo '<input type="hidden" name="transaction_date"  value="' . $data['transaction_date'] . '" />';
?>
     <button type='submit' class="btn btn-primary btn-sm">Update</button>
    <a href="/admin/Employeeadjustment/index.php?emp_id=<?php
    echo $data['emp_custom_id'];
?>"><button type="button" class ='btn btn-secondary btn-sm'>Back</button></a>
      </div>
    </form>

</fieldset>

</body>
</html>

<?php
}
?> 