<?php
include '../../common/menu.php';
include '../../db.php';

if($_GET['id']) {
	$id = $_GET['id'];
//	$salary_month = $_GET['salary_month'];

	$sql = "select * from employee where emp_id='{$id}'";
			$emp_result = mysqli_query($con,$sql);
	$result = $con->query($sql);
	$data = $result->fetch_assoc();

	$con->close();

?>

<body>

<fieldset>
	<legend>Add Salary for <?php echo $data['emp_name'] ?></legend>
	<script language="javascript" type="text/javascript" src="../datetimepicker.js">
    </script>
	<form action="/admin/salary/action/create.php" method="post">
		
		<table  class="table table-striped">
			<tr>
				<th>Employee Id</th>
				<td>
				<?php echo'<input type="text" readonly name="emp_id"  value="' . $id. '"'; ?>
				
				</td>
			
				<th>Employee name</th>
				<td><?php echo $data['emp_name'] ?></td>
			</tr>
			<tr>
                        <td>Select Month :</td>
                        <td>
                        <select name="month" size='1'>
						<?php
						for ($i = 0; $i < 12; $i++) {
							$time  = strtotime(sprintf('%d months', $i));
							$label = date('F', $time);
							$value = date('n', $time);
						echo "<option value='$value'>$label</option>";
						}
							?>
						</select></td>
                        <td>Select Year :</td>
                        <td>
						<?php
// set start and end year range
								$yearArray = range(2014, date('Y'));
						?>
<!-- displaying the dropdown list -->
							<select name="year">
									<option value="">Select Year</option>
							<?php
    foreach ($yearArray as $year) {
        // if you want to select a particular year
        $selected = ($year == date('Y')) ? 'selected' : '';
        echo '<option '.$selected.' value="'.$year.'">'.$year.'</option>';
    }
    ?>
</select></td>
                    </tr>
			
			<tr>

                    <td>Basic : </td>
                    <td><?php echo'<input type="text" name="basic" value="' . $data['basic'] . '"'; ?></td>
                    <td>Incentive : </td>
                    <td><?php echo'<input type="text" name="incentive" value="' . $data['incentive'] . '"'; ?></td>
                </tr>
                <tr>
                    <td>Advance</td>
                    <td><?php echo'<input type="text" name="advance"  value="0"'; ?></td>
                    <td>Deduction</td>
                    <td><?php echo'<input type="text" name="deduction"  value="0"'; ?></td>
                </tr>
               <tr>
                    <td>Remark</td>
                    <td colspan = 3><?php echo'<input type="textarea" name="remark"  value="Remarks" />'; ?></td>
                    
                </tr>
               

		</table>
		<!-- Modal footer -->
      <div class="modal-footer">
	 <?php echo'<input type="hidden" name="id"  value="' . $data['id'] . '" />'; ?>
	  <button type='submit' class="btn btn-primary btn-sm">Add Salary</button>
	<a href="/admin/Salary/index.php?emp_id=<?php echo $data['emp_id']?>"><button type="button" class ='btn btn-secondary btn-sm'>Back</button></a>
      </div>
	</form>

</fieldset>

</body>
</html>

<?php
}
?>