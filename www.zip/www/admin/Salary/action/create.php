<?php 
include '../../../common/menu.php';
require_once '../../../db.php';

if($_POST) {
	$crdate = $_POST['year'].'-'.$_POST['month'].'-'.'1';
	//$createDate->setDate($_POST['month'], $_POST['month'], 1);
	$emp_id = $_POST['emp_id'];
	$id = $_POST['id'];
    //$date = $createDate->format('Y-m-d');];
    $basic=$_POST['basic'];
    $advance=$_POST['advance'];
    $incentive=$_POST['incentive'];
    $deduction=$_POST['deduction'];
	$remark=$_POST['remark'];
	$sql="insert into salary (emp_id,emp_custom_id,salary_month,basic,advance,incentive,deduction,remark,ongoing) value ($id,'".$emp_id."',STR_TO_DATE('". $crdate ." ','%Y-%m-%d'),".$basic.",".$advance.",".$incentive.",".$deduction.",'".$remark."',1)";
	//$sql = "INSERT INTO employee_adjustment (emp_custom_id, credit, debit,transaction_date) VALUES ('$emp_id', $credit, $debit,STR_TO_DATE('" . $date . "','%d-%c-%Y'));";
	if($con->query($sql) === TRUE) {
		echo "<div class='alert alert-success' role='alert'>New Record Successfully Created!!</div>";
		?>
		<a href='../create.php?emp_id=<?php echo $emp_id ?>'><button type='button'class='btn btn-primary btn-sm'>Back</button></a>
		<a href='/admin/Salary/index.php?emp_id=<?php echo $emp_id ?>'><button type='button'class='btn btn-primary btn-sm'>Go to Salary Details</button></a>;
	 <?php } else {
		echo "Error " . $sql . ' ' . $con->connect_error;
	}

	$con->close();
}

?>

