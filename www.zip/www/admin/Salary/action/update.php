<?php 
include '../../../common/menu.php';
require_once '../../../db.php';

if($_POST) {
	$emp_id = $_POST['emp_id'];
    $salary_month =$_POST['transaction_date'];
	$basic=$_POST['basic'];
    $advance=$_POST['advance'];
    $incentive=$_POST['incentive'];
    $deduction=$_POST['deduction'];
	$remark=$_POST['remark'];
	$date = $_POST['year'].'-'.$_POST['month'].'-'.'1';
	$sql="update salary set basic=".$basic.",advance=".$advance.",incentive=".$incentive.",remark='".$remark."',
	salary_month=STR_TO_DATE('" . $date . "','%Y-%m-%d'),deduction=".$deduction." where emp_custom_id='".$emp_id."' and salary_month=STR_TO_DATE('$salary_month','%d-%b-%Y')";
if($con->query($sql) === TRUE) {
		echo "<div class='alert alert-success' role='alert'>Record Updated Successfully!!</div>";
		echo "<a href='../index.php?emp_id=".$emp_id."'><button type='button' class='btn-sm btn btn-success'>Go to Salary Details</button></a>";
	} else {
		echo "Erorr while updating record : ". $sql;
		echo "Erorr while updating record : ". $con->error;
		
	}

	$con->close();

}

?>