<?php
include '../../../common/menu.php';
include '../../../db.php';


if($_POST) {
	$transaction_date = $_POST['transaction_date'];
	$emp_id=$_POST['emp_id'];
	$sql = "delete FROM salary WHERE emp_custom_id = '$emp_id'  and salary_month=STR_TO_DATE('$transaction_date','%d-%b-%Y')";
	if($con->query($sql) === TRUE) {
		echo "<div class='alert alert-success' role='alert'>Removed Successfully!!</div>";
		echo "<a href='/admin/Salary/index.php?emp_id=".$emp_id."'><button type='button'  class='btn btn-primary btn-sm'>Go to Employee details</button></a>";
	} else {
		echo "Error updating record : " . $con->error;
	}

	$con->close();
}

?>