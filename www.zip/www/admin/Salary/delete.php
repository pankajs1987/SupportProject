<?php
include '../../common/menu.php';
include '../../db.php';

if($_GET['id']) {
	$id = $_GET['id'];
	$transaction_date = $_GET['salary_month'];
	$sql = "SELECT * FROM salary WHERE emp_id = '{$id}' and salary_month = STR_TO_DATE('".$transaction_date. "','%d-%c-%Y')";
	$result = $con->query($sql);
	$data = $result->fetch_assoc();

	$con->close();
?>
<body>

<h3>Do you really want to remove ?</h3>
<form action="/admin/Salary/action/remove.php" method="post">

	<input type="hidden" name="transaction_date" value="<?php echo $transaction_date; ?>" />
    <input type="hidden" name="emp_id" value="<?php echo $id; ?>" />
	
	<button type="submit" class='btn btn-primary btn-sm'>Save Changes</button>
	<a href="/admin/Employeeadjustment/index.php?emp_id=<?php echo $data['emp_custom_id']?>"><button type="button" class='btn btn-secondary btn-sm'>Back</button></a>
</form>

</body>

<?php
}
?>