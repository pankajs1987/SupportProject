<?php
include '../../common/menu.php';
include '../../db.php';
$emp_id = $_GET['emp_id'];
$query = "SELECT emp_custom_id,date_format(salary_month,'%d-%b-%Y') as transaction_date,date_format(salary_month,'%b-%Y') as salary_month,basic,incentive,deduction,advance,remark FROM salary WHERE emp_custom_id='{$emp_id}' order by salary_month desc";
			$result=  mysqli_query($con,$query);
			$query = "select * from employee where emp_id='{$emp_id}'";
			$emp_result = mysqli_query($con,$query);
?>
<div class="row">


	<table class="table table-striped">
	<thead>
	<tr class='table-info'>
	<?php while ($data = mysqli_fetch_array($emp_result)) {?>
	<td  colspan=6>Salary Details for Employee Name Mr. <?php echo $data['emp_name']; ?>  </td>
	<td><a href="create.php?salary_month=&id=<?php echo $data['emp_id']; ?>"><button type='button' class="btn btn-primary btn-sm">Add Salary</button></a></td>
	<?php }?>
	</tr>
	</thead>
		<thead>
			<tr>
				
                <th>Salary Month</th>
				<th>Basic</th>
				<th>incentive</th>
				<th>Deductions</th>
				<th>Advance</th>
				<th>Remarks</th>
				<th>Actions</th>
			</tr>
		</thead>
		<tbody>
			<?php
			
			
			while($row=  mysqli_fetch_array($result))
			{
				//$total_credit += $row['credit'];
				//$total_debit += $row['debit'];
				?>
						<tr>
							<td><?php echo $row['salary_month']; ?></td>
							<td><?php echo $row['basic']; ?></td>
							<td><?php echo $row['incentive']; ?></td>
							<td><?php echo $row['deduction']; ?></td>
							<td><?php echo $row['advance']; ?></td>
							<td><?php echo $row['remark']; ?></td>
		
							<td>
							<a href="update.php?salary_month=<?php echo $row['transaction_date']; ?>&id=<?php echo $row['emp_custom_id']; ?>"><button type='button' class="btn btn-primary btn-sm">Edit</button></a>
							<a href='delete.php?salary_month=<?php echo $row['transaction_date']; ?>&id=<?php echo $row['emp_custom_id']; ?>'><button type='button' class="btn btn-danger btn-sm">Remove</button></a>
						</td>	
						</tr>
			
			
			
				<?php
			}
			?>
			
			
		</tbody>
	</table>
</div>

