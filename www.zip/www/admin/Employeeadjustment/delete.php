<?php
include '../../common/menu.php';
include '../../db.php';

if($_GET['id']) {
	$id = $_GET['id'];

	$sql = "SELECT * FROM employee_adjustment WHERE id = {$id}";
	$result = $con->query($sql);
	$data = $result->fetch_assoc();

	$con->close();
?>
<body>

<div class="alert alert-danger" role="alert">
Do you really want to remove ?
</div>
<form action="/admin/Employeeadjustment/action/remove.php" method="post">

	<input type="hidden" name="id" value="<?php echo $data['id'] ?>" />
    <input type="hidden" name="emp_id" value="<?php echo $data['emp_custom_id'] ?>" />
	<button type="submit" class='btn btn-primary btn-sm'>Save Changes</button>
	<a href="/admin/Employeeadjustment/index.php?emp_id=<?php echo $data['emp_custom_id']?>"><button type="button"class='btn btn-primary btn-sm'>Back</button></a>
</form>

</body>

<?php
}
?>