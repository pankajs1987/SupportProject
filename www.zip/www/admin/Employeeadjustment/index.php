<?php
include '../../common/menu.php';
include '../../db.php';
$emp_id = $_GET['emp_id'];
$month="";
$month_year="";
$year="";
 if (isset($_REQUEST['month'])) {
	$month_year = $_GET['month'];
	$str_arr = explode ("-", $month_year);
	$month=$str_arr[0];
	$year=$str_arr[1];	
}
?>	
	<table class="table table-striped">
		<thead>
		<tr >
				<th colspan =5><a class="btn btn-primary btn-sm float-right" href="create.php?emp_id=<?php echo $emp_id ?>" >Add Adjustment</a> </th>
                
			</tr>
			<tr>
				<th>Employee Id</th>
                <th>Date</th>
				<th>Credit</th>
				<th>Debit</th>
				<th>Option</th>
			</tr>
		</thead>
		<tbody>
			<?php
			if($month_year === ""){
				$query = "SELECT id,emp_custom_id,date_format(transaction_date,'%d-%b-%Y') as transaction_date,credit,debit FROM employee_adjustment WHERE emp_custom_id='{$emp_id}'";
			}else{
				$query = "SELECT id,emp_custom_id,date_format(transaction_date,'%d-%b-%Y') as transaction_date,credit,debit FROM employee_adjustment WHERE emp_custom_id='{$emp_id}' and date_format(transaction_date,'%c')='{$month}' and date_format(transaction_date,'%Y')='{$year}' ";
			}
			$result=  mysqli_query($con,$query);
			$total_credit = 0;
			$total_debit = 0;
			while($row=  mysqli_fetch_array($result))
			{
				$total_credit += $row['credit'];
				$total_debit += $row['debit'];
				?>
						<tr>
							<td><?php echo $row['emp_custom_id']; ?></td>
							<td><?php echo $row['transaction_date']; ?></td>
							<td><?php echo $row['credit']; ?></td>
							<td><?php echo $row['debit']; ?></td>
							<td>
							<a class="btn btn-primary btn-sm" href="update.php?id=<?php echo $row['id']; ?>">Edit</a>
							<a class="btn btn-primary btn-sm" href='delete.php?id=<?php echo $row['id']; ?>'>Remove</a>
						</td>	
						</tr>
			
			
			
				<?php
			}
			?>
			
			<tfooter>
			<tr >
			<td class="alert alert-dark">Total Credit</td>
			<td  class="alert alert-info" role="alert">
			<?php echo $total_credit ?>
			</td>
			<td  class="alert alert-dark">Total Dedit</td>
			<td  class="alert alert-info" role="alert">
			<?php echo $total_debit ?>
			</td>
			<td></td>
			</tr>
			<tr colspan = 5>
			<td><a class="btn btn-primary btn-sm" href="/admin/employee/empid.php" >Back</a></td>
			</tr>
			</tfooter>
		</tbody>
	</table>
</div>

