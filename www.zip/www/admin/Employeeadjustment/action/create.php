<?php 
	include '../../../common/menu.php';
	require_once '../../../db.php';

if($_POST) {
	$date = $_POST['transaction_date'];
	$emp_id = $_GET['emp_id'];
	$credit = $_POST['credit'];
	$debit = $_POST['debit'];
	
	$sql = "INSERT INTO employee_adjustment (emp_custom_id, credit, debit,transaction_date) VALUES ('$emp_id', $credit, $debit,STR_TO_DATE('" . $date . "','%d-%c-%Y'));";
	if($con->query($sql) === TRUE) {
		echo "<div class='alert alert-success' role='alert'>New Record Successfully Created</div>";
		echo "<a href='../create.php?emp_id=".$emp_id."'><button type='button' class='btn btn-primary btn-sm'>Back</button></a>";
		echo "<a href='/admin/Employeeadjustment/index.php?emp_id=".$emp_id."'><button type='button' class='btn btn-primary btn-sm'>Go to Adjustment</button></a>";
	}else {
		echo "Error " . $sql . ' ' . $con->connect_error;
	}

	$con->close();
}else{
		echo "<p>Contact Admin</p>";
	
}
?>


