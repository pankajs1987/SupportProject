<?php 
include '../../../common/menu.php';
require_once '../../../db.php';

if($_POST) {
	$emp_id = $_POST['emp_id'];
	$credit = $_POST['credit'];
	$debit = $_POST['debit'];
	$transaction_date = $_POST['transaction_date'];
	$id = $_POST['id'];

	$sql  = "UPDATE employee_adjustment SET credit = $credit, debit = $debit, transaction_date=STR_TO_DATE('".$transaction_date. "','%d-%c-%Y') WHERE id = $id;";
	if($con->query($sql) === TRUE) {
		echo "<div class='alert alert-success' role='alert'>Succcessfully Updated</div>";
		echo "<div class='modal-footer'><a href='../edit.php?id=".$id."'><button type='button' class='btn btn-primary btn-sm'>Back</button></a>";
		echo "<a href='../index.php?emp_id=".$emp_id."'><button type='button' class='btn btn-primary btn-sm'>Go to Adjustment</button></a> </div>";
	} else {
		echo "Erorr while updating record : ". $sql;
		echo "Erorr while updating record : ". $con->error;
		
	}

	$con->close();

}

?>