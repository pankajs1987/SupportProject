<?php
include '../../../common/menu.php';
include '../../../db.php';


if($_POST) {
	$id = $_POST['id'];
	$emp_id=$_POST['emp_id'];
	$sql = "delete from employee_adjustment where id = {$id}";
	if($con->query($sql) === TRUE) {
		echo "<div class='alert alert-success' role='alert'>Successfully removed!!</div>";
		echo "<div class='modal-footer'><a href='/admin/Employeeadjustment/index.php?emp_id=".$emp_id."'><button type='button' class='btn btn-primary btn-sm'>Go to Adjustment</button></a></div>";
	} else {
		echo "Error updating record : " . $con->error;
	}

	$con->close();
}

?>