<?php
include '../../common/menu.php';
include '../../db.php';
?>

<body>
<script language="javascript" type="text/javascript" src="../datetimepicker.js">
    </script>

<fieldset>
	<legend>Add Adjustment</legend>
<?php 
$emp_id = $_GET['emp_id'];
?>
	<form action="/admin/Employeeadjustment/action/create.php?emp_id=<?php echo $emp_id ?>" method="post">
	<input type="hidden" name="emp_id"  />
		<table class="table table-striped">
			<tr>
				<th>Transaction Date</th>
				<td><input id="transaction_date" name="transaction_date" type="text" size="10">
					<a href="javascript:NewCal('transaction_date','ddMMyyyy')"><img src="../../cal.gif" width="16" height="16" border="0" alt="Pick a date"></a>
				</td>
			</tr>		
			<tr>
				<th>Credit</th>
				<td><input type="text" name="credit" value="0" placeholder="Credit" /></td>
			</tr>
			<tr>
				<th>debit</th>
				<td><input type="text" name="debit" value="0" placeholder="Debit" /></td>
			</tr>
			
		</table>
		<div class="modal-footer">
		<button type="submit" class="btn btn-primary btn-sm">Save Changes</button>
		<a href="/admin/Employeeadjustment/index.php?emp_id=<?php echo $emp_id;?>"><button type="button" class ='btn btn-secondary btn-sm'>Back</button></a>
		</div>
	</form>

</fieldset>

</body>