<?php
include '../../common/menu.php';
include '../../db.php';

if($_GET['id']) {
	$id = $_GET['id'];

	$sql = "SELECT adj.id as id,emp.emp_name as emp_name,emp_custom_id,credit,debit,date_format(transaction_date,'%d-%c-%Y') as transaction_date FROM employee_adjustment adj join employee emp on emp.emp_id=adj.emp_custom_id WHERE adj.id = {$id}";
	$result = $con->query($sql);

	$data = $result->fetch_assoc();

	$con->close();

?>

<body>

<fieldset>
	<legend>Edit Adjustment</legend>
	<script language="javascript" type="text/javascript" src="../datetimepicker.js">
    </script>
	<form action="/admin/Employeeadjustment/action/update.php" method="post">
		<table  class="table table-striped">
			<tr>
				<th>Employee Id</th>
				<td><?php echo $data['emp_custom_id'] ?></td>
			</tr>		
			<tr>
				<th>Employee name</th>
				<td><?php echo $data['emp_name'] ?></td>
			</tr>		
			<tr>
				<th>Debit</th>
				<td><input type="hidden" name="emp_id"  value="<?php echo $data['emp_custom_id'] ?>" />
				<input type="text" name="debit" placeholder="Debit" value="<?php echo $data['debit'] ?>" /></td>
			</tr>
			<tr>
				<th>Credit</th>
				<td><input type="text" name="credit" placeholder="Credit" value="<?php echo $data['credit'] ?>" /></td>
			</tr>
			<tr>
				<th>Transaction Date</th>
				<td><input id="transaction_date" name="transaction_date" type="text" value="<?php echo $data['transaction_date'] ?>" size="10">
					<a href="javascript:NewCal('transaction_date','ddMMyyyy')"><img src="../../cal.gif" width="16" height="16" border="0" alt="Pick a date"></a>
				</td>
			</tr>
			<tr>
				<input type="hidden" name="id" value="<?php echo $data['id']?>" />
				
			</tr>
		</table>
		<div class="modal-footer">
		<button type="submit"  class='btn btn-primary btn-sm'>Save Changes</button>
				<a href="/admin/Employeeadjustment/index.php?emp_id=<?php echo $data['emp_custom_id']?>"><button type="button"  class='btn btn-secondary btn-sm'>Back</button></a>
				</div>
	</form>

</fieldset>

</body>
</html>

<?php
}
?>