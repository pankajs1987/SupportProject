<?php
include '../common/menu.php';
include '../db.php';
if (isset($_REQUEST['client_id'])) {
    $client_id = $_REQUEST['client_id'];
    if ($client_id != "" || $client_id != null) {
        $query = "select * from client where client_id='" . $client_id . "'";
        $result = mysqli_query($con,$query) or die(mysql_errno() . mysql_error());
        $row = mysqli_fetch_array($result);
        //echo '<center>';
        echo'<form name="form1" method="POST" action="firstappointmentfinal.php">';
        echo'<input type="hidden" name="client_id" value="' . $client_id . '">';
        echo'<input type="hidden" name="date" value="' . $row['date'] . '">';
        echo '<table class="table table-striped">';
        echo '<tr>';
        echo '<td>';
        echo 'Client id  ';
        echo '</td>';
        echo '<td>';
        echo $row['client_id'];
        echo '</td>';
        echo '</tr>';
		echo '<tr>';
        echo '<td>';
        echo 'Client Name  ';
        echo '</td>';
        echo '<td>';
        echo '<input type="text" name="client_name" value="'.$row['client_name'].'">';
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td>';
        echo 'Age  ';
        echo '</td>';
        echo '<td>';
        echo $row['age'];
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td>';
        echo 'Address  ';
        echo '</td>';
        echo '<td>';
        echo $row['address'];
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td>';
        echo 'Phone Number  ';
        echo '</td>';
        echo '<td>';
        echo $row['phone_no'];
        echo '</td>';
        echo '</tr>';


        echo '<tr>';
        echo '<td>';
        echo 'Date Of Registration ';
        echo '</td>';
        echo '<td>';
        echo $row['date'];
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td>';
        echo 'Refered By ';
        echo '</td>';
        echo '<td>';
        echo '<input type="text" name="dr_refer" value='.$row['dr_refer'].'>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<td>';
        echo 'Problem Description ';
        echo '</td>';
        echo '<td>';
        echo '<textarea name="precaution" rows="2" cols="40"></textarea>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>
        <td>';
        echo 'Priscription ';
        echo '</td>';
        echo '<td>';
        echo '<textarea name="refer" rows="2" cols="40"></textarea>';
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td>';
        echo 'Total Amount to be Paid ';
        echo '</td>';
        echo '<td>';
        echo '<input type="text" name="amount">(Default Value is 0 )';
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td>';
        echo 'Amount Paying Today ';
        echo '</td>';
        echo '<td>';
        echo '<input type="text" name="paying">(Default Value is 0 )';
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td>';
        echo 'Status ';
        echo '</td>';
        echo '<td>
						<select name="status">
							<option value="">---Select---</option>
							<option value="Active">Active</option>
							<option value="Final">Final</option>
						</select>';
        echo '</td>';
        echo '</tr>';


        echo '<tr>';
        echo '<td>';
        echo '</td>';
        echo '<td>';
        echo '<input type="submit" Value="Submit" name="submit">';
        echo '</td>';
        echo '</tr>';


        echo '</table>';
        echo'</form>';
        //echo '</center>';
    }
} else if(isset ($_REQUEST['amount'])){
    $precaution=$_REQUEST['precaution'];
    $refer=$_REQUEST['refer'];
    $client_name=$_REQUEST['client_name'];
    $client_id=$_REQUEST['client_id'];
    $amount=$_REQUEST['amount'];
    $paying=$_REQUEST['paying'];
    $date=$_REQUEST['date'];
    $status=$_REQUEST['status'];
	$dr_refer=$_REQUEST['dr_refer'];
    $query="update client SET amount=".$amount." ,client_name='".$client_name."',status='".$status."',problem='".$precaution."',refer='".$refer."',dr_refer='".$dr_refer."' where client_id='".$client_id."'";
    mysqli_query($con,$query) or die(mysql_errno().":".  mysql_error() ."Some Problem has been Occured in Executing Your Query,Please Contact Your System Administrator");
    $query1="insert into paid (client_id,total_payment,paid,date) value('".$client_id."',".$amount.",".$paying.",'".$date."')";
    mysqli_query($con,$query1) or die(mysql_errno().":".  mysql_error() ."Some Problem has been Occured in Executing Your Query1,Please Contact Your System Administrator");
        echo 'Result Updated,Want to Add More Client Details ';
    }else {
?>
    <form method="post" action="firstappointment.php" ><center>
    <div class="col-md-16 text-center"><h3>First Appointment of Client</h3></div>
            <table class="table table-striped">
                <thead>
                </thead>
                <tbody>
                    <tr>
                        <td>Enter Client Id :</td>
                        <td><input name="client_id" type="text" maxlength="100" ></td>
                    </tr>
                    
                </tbody>
            </table>
            <div class="col-md-16 text-center"><input type="submit" class='btn btn-primary btn-sm' value="Submit"></div>
        </center>
    </form>
<?php } ?>
<?php include '../footer.php'; ?>