
<head>
    <script language="javascript" type="text/javascript" src="datetimepicker.js">
    </script>

    <style type="text/css">
        .style1 {
            font-size: large;
        }
        .style2 {
            text-align: center;
        }
    </style>
</head>

<?php
include '../common/menu.php';
include '../db.php';

$paid = 0;
if (isset($_REQUEST['start_date'])) {
    $start_date = $_REQUEST['start_date'];
    $query = "select p.client_id as client_id,c.client_name as client_name,p.date,p.next_appointment as next_appointment from paid p,client c where next_appointment = STR_TO_DATE('" . $start_date . "','%d-%c-%Y') and p.client_id=c.client_id group by client_id";
    $result = mysqli_query($con,$query) or die(mysql_errno() . " : " . mysql_error() . " : Please Contact Your System Administrator");
?>
    <center><h2>Appointment Details Of Clients  <?php echo $start_date; ?>(dd-mm-yyyy)</h2> </center>
    <table  class="table table-striped" >
        <thead>
            <tr>
                <th nowrap>Client ID</th>
                <th nowrap>Client Name</th>
                <th nowrap>Date</th>
                <th nowrap>Next Appointment</th>

            </tr>
        </thead>
        <tbody>

<?php
    while ($row = mysqli_fetch_assoc($result)) {
?>
        <tr><center>
            <td nowrap><?php echo $row['client_id'] ?></td>
            <td nowrap><?php echo $row['client_name'] ?></td>
            <td nowrap><?php echo $row['date'] ?></td>
            <td nowrap><?php echo $row['next_appointment'] ?></td>
</center>
        </tr>


<?php } ?>

    </tbody>
</table>

        <?php
        include '../footer.php';
    } else {
        ?><form method="post" action="">
    <center>
        <br>
        <strong font-size: large text-align: center >Appointments on Particular Dates<br>
        </strong><br>

        <strong font-size: large text-align: center  >Enter Date :</strong> <input id="demo3" name="start_date" type="text" size="25"><a href="javascript:NewCal('demo3','ddMMyyyy')"><img src="../cal.gif" width="16" height="16" border="0" alt="Pick a date"></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

        <br>
        <br>
        <br>
        <input name="Submit1" type="submit" value="Submit Details" style="width: 101px"><br>

    </center>
</form>

<?php } ?>