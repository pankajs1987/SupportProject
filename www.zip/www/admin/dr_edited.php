<?php

include '../db.php';
include 'menu.php';
$dr_old = $_REQUEST['dr_old'];
$dr_new = $_REQUEST['dr_new'];


if (isset($_REQUEST['dr_new'])) {
      $query = "update client set dr_refer='".$dr_new."' where dr_refer='".$dr_old."'";
      mysqli_query($con,$query) or die(mysql_errno() . ":" . mysql_error() . " Fatal Error,Please Contact Your Administrator");
   
    //echo 'Contact Updated Successfully';
     header('Location:edit_doctor.php');
    
}
?>
<?php include '../footer.php'; ?>