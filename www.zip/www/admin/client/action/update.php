<?php 
require_once '../../../db.php';

if($_POST) {
	$client_id = $_POST['client_id'];
   $problem=$_POST['problem'];
    $status=$_POST['status'];
    $dr_refer=$_POST['dr_refer'];
	$refer=$_POST['refer'];
   $sql="update client set problem='".$problem."',status='".$status."',refer='".$refer."',dr_refer='".$dr_refer."' where client_id='".$client_id."'";
	if($con->query($sql) === TRUE) {
		echo "status:{message:details updated successfully}";
	} else {
	echo "status:{message:Error Updating Records}";
		echo "Erorr while updating record : ". $con->error;
		
	}

$con->close();

}

 ?>