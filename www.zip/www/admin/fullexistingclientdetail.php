<?php
include '../common/menu.php';
include '../db.php';
if(isset ($_REQUEST['client_id']))
{
    $client_id=$_REQUEST['client_id'];
    $query="SELECT p.id,p.client_id as client_id,p.next_appointment as next_appointment,c.client_name as client_name,p.total_payment as total,p.paid as paid,p.date as date FROM paid p,client c where p.client_id=c.client_id and p.client_id='".$client_id."'";
    $result=mysqli_query($con,$query) or die(mysql_errno().":".  mysql_error() .": Please Contact Your System Administrator");
    $query = "select * from client where client_id='$client_id'";
	$emp_result = mysqli_query($con,$query);
	?>
	<div><p  class="h6 mx-auto" style="width: 800px;"></div>
	
	   <center> <table  class="table table-striped">
	 
        <thead>
		<?php while ($data = mysqli_fetch_array($emp_result)) {?>
	
	
	<tr><th colspan=6 class="table-info">Transaction Details for Client Id : <?php echo $data['client_id']; ?> ,Client Name Mr. <?php echo $data['client_name']; ?></th></tr>
<?php }?>    
	<tr>
			<th>Transaction ID</th>
                <th>Initial Amount</th>
                <th>Paid </th>
				 <th>Unpaid </th>
                <th>Date </th>
                <th>Next Appointment Date</th>
            </tr>
        </thead>
        <tbody>


    <?php
    $total_amount=0;
    $total_paid=0;
	$remain=0;
	$unpaid=$remain;
    while($row=mysqli_fetch_array($result))
        {
$total_amount+=$row['total'];
$total_paid+=$row['paid'];
$remain=$total_amount-$total_paid;
$unpaid+=$remain;
        ?>

            <tr>
				<td nowrap><?php echo $row['id']; ?></td>
                <td nowrap><?php echo $row['total']; ?></td>
                <td nowrap><?php echo $row['paid']; ?></td>
				<td nowrap><?php echo $remain; $remain=0; ?></td>
                <td nowrap><?php echo $row['date']; ?></td>
                <td nowrap><?php echo $row['next_appointment']; ?></td>
            </tr>
       <?php }
    ?>
           
        </tbody>
    </table>
       </center>
<div class='modal-footer'>
<p class="h5">Total : <?php echo 'Rs '.$total_amount; ?></p>,
<p class="h5"> Paid: <?php echo 'Rs '.$total_paid; ?></p></div>
<div class='modal-footer'>
<p class="h5"> Due : Rs <?php echo ($total_amount-$total_paid);?></p>
</div>
        <?php            include '../footer.php';
}


else{
?>
<form name="frm" action="fullexistingclientdetail.php">
    <center>

        <table  class="table table-striped">
                <tbody>
                    <tr>
                        <td>Enter Client id </td>
                        <td><input type="text" name="client_id" value="" size="20" /> </td>
                    </tr>
                   
                </tbody>
            </table>

<div class="modal-footer"><input class="btn btn-secondary btn-sm" type="reset" value="Reset" />
                        <input type="submit" class="btn btn-primary btn-sm" value="Submit Details" /></div>


    </center>
</form>

<?php include '../footer.php'; }?>