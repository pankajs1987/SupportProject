 <?php
include '../common/menu.php';
        include '../db.php';
        
if(isset ($_REQUEST['client_id']))
{
    $client_id=$_REQUEST['client_id'];
                $query = "select * from client where client_id='".$client_id."'";
                $result =  mysqli_query($con,$query) or die('Could not Execute Query');

                ?><center>
<table border="0" width="20" cellspacing="5" cellpadding="5">
    <thead>
        <tr>
            <th width="100%" nowrap>Client ID</th>
            <th width="100%" nowrap>Client Name</th>
                <th width="100%" nowrap>Doctor's Reference</th>
            
        </tr>
    </thead>
<tbody>
                <?php
                while($row=mysqli_fetch_array($result)) {
        ?><tr>
            <td width="100%" nowrap><?php echo $row['client_id']; ?></td>
            <td width="100%" nowrap><?php echo $row['client_name']; ?></td>
            <td width="100%" nowrap><?php echo $row['dr_refer']; ?></td>
           
        </tr>
          <?php

                }


           ?>


    </tbody>
</table>
                </center>
<?php   include '../footer.php'; }  else{ ?>


<?php } ?>
}