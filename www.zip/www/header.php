<style type="text/css">
.style1 {
	font-size: 24pt;
	font-family: "Monotype Corsiva";
	color: #336699;
}
</style>
<center style="width: 876px"><table style="width: 100%">
	<tr>
		<td width="369" style="width: 371px">
  <img alt="Avantika Technologies" src="Logo.jpg" width="370" height="200"></td>
		<td width="495" class="style1">Welcome To the World Of New Technology</td>
	</tr>
	</table></center>

<br />