<?php
include '../common/menu.php';
include '../db.php';

if(isset($_REQUEST['client_id'])) {
    $client_id = $_REQUEST['client_id'];

    if ($client_id != "" || $client_id != null) {
        $query = "select * from client where client_id='".$client_id."'";
        $result = mysqli_query($con,$query);
        $nrow = mysqli_num_rows($result);
        if ($nrow > 0) {
            $row = mysqli_fetch_array($result, MYSQL_ASSOC);
            echo '<center>';
            echo '<h2>Client Details</h2> ';
            echo'<form name="form1" action="view_detail_client.php">';
            echo '<table  class="table table-striped">';

            echo '<tr>';
            echo '<td>';
            echo 'Client ID  ::';
            echo '</td>';
            echo '<td>';
            echo $row['client_id'];
            echo '</td>';
            echo '</tr>';


            echo '<tr>';
            echo '<td>';
            echo 'Client Name  ::';
            echo '</td>';
            echo '<td>';
            echo $row['client_name'];
            echo '</td>';
            echo '</tr>';

            echo '<tr>';
            echo '<td>';
            echo 'Phone Number  ::';
            echo '</td>';
            echo '<td>';
            echo $row['phone_no'];
            echo '</td>';
            echo '</tr>';

            echo '<tr>';
            echo '<td>';
            echo 'Date Of Meeting   ::';
            echo '</td>';
            echo '<td>';
            echo $row['date'];
            echo '</td>';
            echo '</tr>';

            echo '<tr>';
            echo '<td>';
            echo 'Problem Discription ::';
            echo '</td>';
            echo '<td>';
            echo $row['problem'];

            echo '</td>';
            echo '</tr>';

            echo '<tr>';
            echo '<td>';
            echo 'Priscription ::';
            echo '</td>';
            echo '<td>';
            echo $row['refer'];
            echo '</td>';
            echo '</tr>';

            echo '<tr>';
            echo '<td>';
            echo 'Doctor Reference ::';
            echo '</td>';
            echo '<td>';
            echo $row['dr_refer'];
            echo '</td>';
            echo '</tr>';
            echo '</tr>';
            echo '</table>';
            echo'</form>';

            echo '</center>';
        }
    }
} else {
?>
    <form method="get" action="view_client.php" ><center>
            <table  class="table table-striped">
                <thead>
                    <tr>

                        <th> Client Details</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Enter Client Id :</td>
                        <td><input name="client_id" type="text" maxlength="100" >     </td>
                    </tr>
                    <tr>

                        <td><center><input type="submit" value="Submit">    </center></td>
                    </tr>
                </tbody>
            </table>
        </center>
    </form>
<?php } ?>
<?php include '../footer.php'; ?>