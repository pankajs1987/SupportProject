﻿<html>
    <head>
        <script language="javascript" type="text/javascript" src="datetimepicker.js">

            
        </script>


    </head>
    <body>

        <?php
        include '../common/menu.php';
        include '../db.php';
        if (isset($_REQUEST['client_id'])) {
            $client_id = $_REQUEST['client_id'];
            $client_name = $_REQUEST['client_name'];
            $age = $_REQUEST['age'];
            $phone_no = $_REQUEST['phone_no'];
            $date = $_REQUEST['date'];
            $address = $_REQUEST['address'];
            $referby = $_REQUEST['referby'];

            if ($client_name != "" || $client_name != null) {
                $query = "insert into client (client_id,client_name,age,phone_no,address,date,dr_refer) values ('" . $client_id . "','" . $client_name . "','" . $age . "','" . $phone_no . "','" . $address . "',STR_TO_DATE('" . $date . "','%d-%c-%Y'),'" . $referby . "')";
                $result = mysqli_query($con,$query) or die(mysqli_error($con) . 'Could not Execute Query');
                $nrow = 0;

                //$nrow = mysql_affected_rows($result);
                if (mysqli_affected_rows($con)>0) {
                    echo '<center>Record Added Successfully</center>';
                }
            }
        ?>



            
        <?php } ?>
                


                <form method="post" action="client_registration.php" ><center>
                        <table class="table table-striped">
                            <thead>
                                <tr>

                                    <th colspan=4>Enter Client Details</th>
                                </tr>
                            </thead>
                            <tbody>

                                <tr>
                                    <td>Enter Client id :</td>
                                    <td>
                                        <input name="client_id" type="text" maxlength="100" ><a href="checkclient_id.php" target="_new">Check if Client Exist</a>

                                    </td>
                                </tr>



                                <tr>
                                    <td>Enter Client Name :</td>
                                    <td>
                                        <input name="client_name" type="text" maxlength="100" >

                                    </td>
                                </tr>
                                <tr>
                                    <td>Age&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :</td>
                                    <td>
                                        <input name="age" type="text" maxlength="100" >

                                    </td>
                                </tr>
                                <tr>
                                    <td>Address&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :</td>
                                    <td>
                                        <input name="address" type="text" maxlength="900" >

                                    </td>
                                </tr>
                                <tr>
                                    <td>Phone Number :</td>
                                    <td>
                                        <input name="phone_no" type="text" maxlength="100" >

                                    </td>
                                </tr>

                                <tr>
                                    <td>Enter Date :</td>
                                    <td>
                                        <input id="demo3" name="date" type="text" size="25"><a href="javascript:NewCal('demo3','ddMMyyyy')"><img src="../cal.gif" width="16" height="16" border="0" alt="Pick a date"></a>

                                    </td>
                                </tr>
                                <tr>
                                    <td>Refered By :</td>
                                    <td>
                                        <input name="referby" type="text" maxlength="300" >

                                    </td>
                                </tr>

                                <tr>
                                    <td></td>
                                    <td><center><input type="submit" value="Submit">    </center></td>
                                </tr>
                            </tbody>
                        </table>
                    </center>
                </form>
            </body>
        </html>
<?php include '../footer.php'; ?>