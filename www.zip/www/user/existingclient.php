<?php
include '../db.php';
include '../common/menu.php'
if(isset ($_REQUEST['client_id']))
{
    $client_id=$_REQUEST['client_id'];
    $query="SELECT p.client_id,c.client_name as client_name,sum(p.total_payment) as total,sum(p.paid) as paid,count(p.client_id) as meeting FROM paid p,client c where p.client_id=c.client_id and p.client_id='".$client_id."'";
    $result=mysql_query($query,$con) or die(mysql_errno().":".  mysql_error() .": Please Contact Your System Administrator");
    ?>
       <center> <table border="2" width="3" cellspacing="3" cellpadding="4">
        <thead>
            <tr>
                <th>Client ID</th>
                <th>Client Name</th>
                <th>Total Amount</th>
                <th>Total Paid </th>
                <th>Due</th>
                <th>Total Meeting</th>
            </tr>
        </thead>
        <tbody>


    <?php
    while($row=mysql_fetch_array($result))
        {

            $due=$row['total']-$row['paid'];

        ?>

            <tr>

                <td nowrap><?php echo $row['client_id']; ?></td>
                <td nowrap><?php echo $row['client_name']; ?></td>
                <td nowrap><?php echo $row['total']; ?></td>
                <td nowrap><?php echo $row['paid']; ?></td>
                <td nowrap><?php echo $due ?></td>
                <td nowrap><?php echo $row['meeting']; ?></td>
            </tr>
       <?php }
    ?>

        </tbody>
    </table>
           <form name="frm" action="fullexistingclientdetail.php" method="POST" target="_blank">
               <?php echo '<input type="hidden" name="client_id" value="'.$client_id.'" />'?>
               <input type="submit" value="Click here For Date wise Details" />
           </form>
       </center><br><br><br>
       <center><h2>Enter Today's Amount to be Paid</h2>

       <form action="existingclientaddamount.php" method="POST">
           <table border="1">
                   <tbody>
                       <tr>
                           <td nowrap>Add Amount to Total :</td>
                           <td><input type="text" name="total" value="0" />(Update,if Paying)</td>
                       </tr>

                       <tr>
                           <td nowrap>Enter Amount Paid :</td>
                           <td><input type="text" name="amt" value="" /></td>
                       </tr>
                       <?php echo '<input type="hidden" name="client_id" value="'.$client_id.'" />'?>
                       <tr>
                           <td></td>
                           <td><input type="submit" value="Add Details" /></td>
                       </tr>
                   </tbody>
               </table>

       </form>
           </center>
        <?php

}

else
    {


?>
<center><h2>Existing Client Details</h2>
<form name="frm" action="existingclient.php" method="POST">
    <table border="2" cellpadding="3">
        <thead>
            </thead>
        <tbody>
            <tr>
                <td>Enter Client id</td>
                <td><input type="text" name="client_id" value="" size="6" /></td>
                
            </tr>
            <tr>
                <td><input type="reset" value="Reset" name="submit" /></td>
                <td><input type="submit" value="Submit" name="submit" /></td>
                
            </tr>
        </tbody>
    </table>



</form></center>
       <?php }
       ?>
<?php include '../footer.php'; ?>