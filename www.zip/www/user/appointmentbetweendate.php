﻿
<head>
<script language="javascript" type="text/javascript" src="datetimepicker.js">  
        </script>

<style type="text/css">
.style1 {
	font-size: large;
}
.style2 {
	text-align: center;
}
</style>
</head>

<?php

include '../common/menu.php'
include '../db.php';
$paid=0;
if(isset($_REQUEST['start_date']) && isset ($_REQUEST['end_date']))
    {
    $start_date=$_REQUEST['start_date'];
    $end_date=$_REQUEST['end_date'];
    $query="select * from paid where date between STR_TO_DATE('".$start_date."','%d-%c-%Y') and STR_TO_DATE('".$end_date."','%d-%c-%Y')";
    $result=mysqli_query($query,$con) or die(mysql_errno()." : ".  mysql_error()." : Please Contact Your System Administrator");
    
    ?>
<center><h2>Appointment Details Of Clients from <?php echo $start_date." TO ".$end_date;?>(dd-mm-yyyy)</h2> </center>
<table border="1" align="center">
            <thead>
                <tr>
                    <th>Client ID</th>
                    
                    <th>Date</th>
                    
                     </tr>
            </thead>
            <tbody>

    <?php
        while($row=mysqli_fetch_array($result))
        {
            
            ?>
                <tr>
                    <td><a href="client_detail.php?client_id=<?php echo $row['client_id'] ?>" target="_new"><?php echo $row['client_id'] ?></a></td>
                    
                    <td><?php echo $row['date'] ?></td>
                    
                </tr>


            <?php
        }?>
                
        </tbody>
        </table>

        <?php
                include '../footer.php';
    }
    else{
?><form method="post" action="">
	
		<br>
		<strong font-size: large text-align: center >Appointments Between Dates<br>
		</strong><br>
		
		<strong font-size: large text-align: center  >Enter Starting Date :</strong> <input id="demo3" name="start_date" type="text" size="25"><a href="javascript:NewCal('demo3','ddMMyyyy')"><img src="../cal.gif" width="16" height="16" border="0" alt="Pick a date"></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<strong>Select End Date : </strong><input id="demo4" name="end_date" type="text" size="25"><a href="javascript:NewCal('demo4','ddMMyyyy')"><img src="../cal.gif" width="16" height="16" border="0" alt="Pick a date"></a>
			<br>
			<br>
			<br>
			<input name="Submit1" type="submit" value="Submit Details" style="width: 101px"><br>
		
	
</form>

<?php } ?>