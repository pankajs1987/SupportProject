$(document).ready(function () {

    console.log("Client Page...");
    
    $(document).on('click', '.addTransaction-submit', function () {
        var baseURL = document.getElementById("client").getAttribute("baseURL");
        $.ajax({
            url: baseURL + '/admin/existingclientaddamount.php', //this is the submit URL
            type: 'GET', //or POST
            data: $('#add-transaction-form').serialize(),
            success: function (data) {

                $('#addTransaction').modal('hide');
                alert('Transaction details added successfully');
            }
        });

    });
	
	   $(document).on('click', '.updateClientDetails-submit', function () {
        var baseURL = document.getElementById("client").getAttribute("baseURL");
		console.log($('#updateClientDetails').serialize());
        $.ajax({
			url: baseURL + '/admin/client/action/update.php', //this is the submit URL
			type: 'POST', //or POST
            data: $('#updateClientDetails').serialize(),
            success: function (data) {
			    alert('Transaction details added successfully');
            }
        });

    });

    $(document).on('click', '.view-transaction', function () {
        var baseURL = document.getElementById("client").getAttribute("baseURL");
		var client_id = $( ".client_id" ).val();
		console.log(client_id);
		 $('.viewTransactionDetails').html('loading');
        $.ajax({
            url: baseURL + '/admin/getClientTransations.php', //this is the submit URL
            type: 'get',
            data: {
                client_id: client_id
            },
            success: function (response) {
				console.log(response);
				$('#viewTransaction').modal('show'); 
                // Add response in Modal body
              //  $('.viewTransactionDetails').html(response);

                // Display Modal
                $('#viewTransaction').modal('show');
            },
			error: function(response){
				console.log(response);
			}
        });

    });


$('.tabs').bind('change', function (e) {
    var now_tab = e.target // activated tab

    // get the div's id
    var divid = $(now_tab).attr('href').substr(1);
	console.log("=========>>>>>>>> "+divid);
	console.log("=========>>>>>>>> "+now_tab);
    //$.getJSON('xxx.php').success(function(data){
      //  $("#"+divid).text(data.msg);
    //});
})


});
